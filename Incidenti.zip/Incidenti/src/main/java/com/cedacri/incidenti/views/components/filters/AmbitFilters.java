package com.cedacri.incidenti.views.components.filters;

import com.cedacri.incidenti.model.IncidentAmbit;
import com.cedacri.incidenti.views.components.Buttons;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.textfield.IntegerField;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.theme.lumo.LumoUtility;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import lombok.NonNull;
import org.springframework.data.jpa.domain.Specification;

import java.util.ArrayList;
import java.util.List;

public class AmbitFilters extends Div implements Specification<IncidentAmbit> {

    private final IntegerField id = new IntegerField("Id");

    private final TextField ambit = new TextField("Ambit");

    public AmbitFilters(Runnable onSearch) {
        setWidthFull();
        addClassName("filter-layout");
        addClassNames(LumoUtility.Padding.Horizontal.LARGE, LumoUtility.Padding.Vertical.MEDIUM,
                LumoUtility.BoxSizing.BORDER);
        id.setPlaceholder("Id");
        ambit.setPlaceholder("Ambit");

        Button resetBtn = new Button("Reset");
        resetBtn.addThemeVariants(ButtonVariant.LUMO_TERTIARY);
        resetBtn.addClickListener(e -> {
            id.clear();
            ambit.clear();
            onSearch.run();
        });

        Div actions = new Div(resetBtn, Buttons.getSearchBtn(onSearch));
        actions.addClassName(LumoUtility.Gap.SMALL);
        actions.addClassName("actions");

        add(id, ambit, actions);
    }

    @Override
    public Predicate toPredicate(@NonNull Root<IncidentAmbit> root, @NonNull CriteriaQuery<?> query, @NonNull CriteriaBuilder criteriaBuilder) {
        List<Predicate> predicates = new ArrayList<>();
        if (!id.isEmpty()) {
            Integer typeIdFilter = id.getValue();
            Predicate fullName = criteriaBuilder.equal(root.get("id"),
                    typeIdFilter);
            predicates.add(criteriaBuilder.or(fullName));
        }

        if (!ambit.isEmpty()) {
            String nameFilter = ambit.getValue().toLowerCase();
            Predicate fullName = criteriaBuilder.like(criteriaBuilder.lower(root.get("name")),
                    nameFilter + "%");
            predicates.add(criteriaBuilder.or(fullName));
        }

        return criteriaBuilder.and(predicates.toArray(Predicate[]::new));
    }
}
