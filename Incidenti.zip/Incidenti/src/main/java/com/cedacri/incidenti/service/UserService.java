package com.cedacri.incidenti.service;

import com.cedacri.incidenti.model.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import java.util.List;

public interface UserService {

    User save(User user);

    User update(User user);

    User findById(Integer id);

    List<User> findAll();

    boolean delete(Integer id);

    User getUserByUserName(String username);

    User getUserFromSecurityContext();

    Page<User> list(Pageable pageable);

    Page<User>list(Pageable pageable, Specification<User> filter);

}
