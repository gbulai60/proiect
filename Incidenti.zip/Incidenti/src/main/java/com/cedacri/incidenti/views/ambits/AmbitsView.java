package com.cedacri.incidenti.views.ambits;

import com.cedacri.incidenti.model.IncidentAmbit;
import com.cedacri.incidenti.service.IncidentAmbitService;
import com.cedacri.incidenti.views.MainLayout;
import com.cedacri.incidenti.views.components.Buttons;
import com.cedacri.incidenti.views.components.Layouts;
import com.cedacri.incidenti.views.components.Notifications;
import com.cedacri.incidenti.views.components.dialogs.Dialogs;
import com.cedacri.incidenti.views.components.filters.AmbitFilters;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.confirmdialog.ConfirmDialog;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.spring.data.VaadinSpringDataHelpers;
import com.vaadin.flow.theme.lumo.LumoUtility;
import jakarta.annotation.security.RolesAllowed;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;

@PageTitle("Ambits")
@Route(value = "ambits", layout = MainLayout.class)
@RolesAllowed("ADMIN")
public class AmbitsView extends Div {

    private Grid<IncidentAmbit> grid;
    private final AmbitFilters filters;
    private final IncidentAmbitService ambitService;
    private final Button createAmbitButton;

    @Autowired
    public AmbitsView(IncidentAmbitService ambitService) {
        this.ambitService = ambitService;
        setSizeFull();
        addClassNames("ambits-view");
        filters = new AmbitFilters(this::refreshGrid);
        createAmbitButton = Buttons.getAddButton("Create new ambit", e -> openCreateDialog());

        VerticalLayout layout = new VerticalLayout(Layouts.getMobileFilters(filters), filters, createButtonsLayout(), createGrid());
        layout.setSizeFull();
        layout.setPadding(false);
        layout.setSpacing(false);
        add(layout);
    }

    private HorizontalLayout createButtonsLayout() {
        return Layouts.getButtonsLayout(createAmbitButton);
    }

    private HorizontalLayout createComponentButtonsLayout(IncidentAmbit item) {
        Button editButton = Buttons.getEditButton(e -> openEditDialog(item));
        Button deleteButton = Buttons.getDeleteButton(e -> openDeleteDialog(item.getId()));

        return Layouts.getActionsLayout(editButton, deleteButton);
    }

    private Component createGrid() {
        Grid<IncidentAmbit> grid = createAmbitGrid();
        grid.addThemeVariants(GridVariant.LUMO_NO_BORDER);
        grid.addClassNames(LumoUtility.Border.TOP, LumoUtility.BorderColor.CONTRAST_10);

        return grid;
    }

    private Grid<IncidentAmbit> createAmbitGrid() {
        grid = new Grid<>(IncidentAmbit.class, false);
        grid.addColumn("id").setAutoWidth(true).setHeader("Id");
        grid.addColumn("name").setAutoWidth(true).setHeader("Name");
        grid.addComponentColumn(this::createComponentButtonsLayout);
        grid.setItems(query -> ambitService.list(
                PageRequest.of(query.getPage(), query.getPageSize(), VaadinSpringDataHelpers.toSpringDataSort(query)),
                filters).stream());
        grid.addThemeVariants(GridVariant.LUMO_NO_BORDER);
        grid.addClassNames(LumoUtility.Border.TOP, LumoUtility.BorderColor.CONTRAST_10);
        return grid;
    }

    private void refreshGrid() {
        grid.getDataProvider().refreshAll();
    }

    private void openEditDialog(IncidentAmbit item) {
        Dialog editDialog = Dialogs.getEditAmbitDialog(item, this::saveAmbit, this::refreshGrid);
        editDialog.open();
    }

    private void openCreateDialog() {
        Dialog addDialog = Dialogs.getCreateAmbitDialog(this::saveAmbit, this::refreshGrid);
        addDialog.open();
    }

    private void openDeleteDialog(Integer id) {
        ConfirmDialog deleteDialog = Dialogs.getDeleteDialog(id, this::deleteAmbit);
        deleteDialog.open();
    }

    private void saveAmbit(IncidentAmbit ambit) {
        ambitService.save(ambit);
        Notifications.showSuccessNotification("Ambit saved successfully!");
        refreshGrid();
    }

    private void deleteAmbit(Integer id) {
        ambitService.delete(id);
        refreshGrid();
        Notifications.showInfoNotification("Origin deleted successfully");
    }
}
