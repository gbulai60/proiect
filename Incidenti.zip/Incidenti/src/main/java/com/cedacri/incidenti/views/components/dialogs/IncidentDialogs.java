package com.cedacri.incidenti.views.components.dialogs;

import com.cedacri.incidenti.model.Incident;
import com.cedacri.incidenti.model.IncidentOrigin;
import com.cedacri.incidenti.model.IncidentType;
import com.cedacri.incidenti.utils.converter.StringToIncidentOriginConverter;
import com.cedacri.incidenti.utils.converter.StringToIncidentTypeConverter;
import com.cedacri.incidenti.views.components.Buttons;
import com.cedacri.incidenti.views.components.Notifications;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.datetimepicker.DateTimePicker;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextArea;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.Binder;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.stream.Collectors;

@Component
public class IncidentDialogs {

    public static Dialog editIncidentDialog(Integer userId, Incident item, List<String> subsystems, List<String> urgencies,
                                            List<String> subcauses, List<String> applicationTypes, List<IncidentType> incidentTypes,
                                            List<IncidentOrigin> incidentOrigins, Consumer<Incident> saveHandler, Runnable closeHandler){
        Dialog dialog = new Dialog();
        dialog.setHeaderTitle("Edit incident");
        dialog.setWidth("30%");

        VerticalLayout fieldsLayout = new VerticalLayout();
        fieldsLayout.setWidthFull();

        TextField incidentSummary = new TextField("Summary");
        incidentSummary.setValue(item.getProblemSummary());

        TextArea incidentDescription = new TextArea("Description");
        incidentDescription.setValue(item.getProblemDescription());

        DateTimePicker openDateField = new DateTimePicker("Open date");
        openDateField.setValue(item.getOpenDate());

        DateTimePicker closeDateField = new DateTimePicker("Close date");
        closeDateField.setValue(item.getCloseDate());

        ComboBox<String> subsystemCombo = new ComboBox<>("Subsystem");
        subsystemCombo.setItems(subsystems);
        subsystemCombo.setValue(item.getSubsystem());

        ComboBox<String> urgencyCombo = new ComboBox<>("Urgency");
        urgencyCombo.setItems(urgencies);
        urgencyCombo.setValue(item.getUrgency());

        ComboBox<String> subcauseCombo = new ComboBox<>("Subcause");
        subcauseCombo.setItems(subcauses);
        subcauseCombo.setValue(item.getSubcause());

        ComboBox<String> applicationTypeCombo = new ComboBox<>("Application type");
        applicationTypeCombo.setItems(applicationTypes);
        applicationTypeCombo.setValue(item.getApplicationType());

        ComboBox<String> incidentTypeCombo = new ComboBox<>("Incident Type");
        incidentTypeCombo.setItems(incidentTypes.stream()
                .map(IncidentType::getName)
                .collect(Collectors.toList()));
        incidentTypeCombo.setValue(item.getIncidentType().getName());

        ComboBox<String> incidentOriginCombo = new ComboBox<>("Origin");
        incidentOriginCombo.setItems(incidentOrigins.stream()
                .map(IncidentOrigin::getName)
                .collect(Collectors.toList()));
        incidentOriginCombo.setValue(item.getOrigin().getName());

        Binder<Incident> binder = new Binder<>(Incident.class);
        binder.setBean(item);
        binder.setValidatorsDisabled(true);

        binder.forField(incidentSummary)
                .asRequired("Summary is required")
                .bind(Incident::getProblemSummary, Incident::setProblemSummary);

        binder.forField(incidentDescription)
                .asRequired("Description is required")
                .bind(Incident::getProblemDescription, Incident::setProblemDescription);

        binder.forField(subsystemCombo)
                .asRequired("Subsystem cannot be blank")
                .bind(Incident::getSubsystem, Incident::setSubsystem);

        binder.forField(urgencyCombo)
                .asRequired("Urgency cannot be blank")
                .bind(Incident::getUrgency, Incident::setUrgency);

        binder.forField(subcauseCombo)
                .asRequired("Subcause cannot be blank")
                .bind(Incident::getSubcause, Incident::setSubcause);

        binder.forField(applicationTypeCombo)
                .asRequired("Application type cannot be blank")
                .bind(Incident::getApplicationType, Incident::setApplicationType);

        binder.forField(incidentTypeCombo)
                .withConverter(new StringToIncidentTypeConverter(incidentTypes))
                .withValidator(Objects::nonNull, "Incident type cannot be null")
                .bind(Incident::getIncidentType, Incident::setIncidentType);

        binder.forField(incidentOriginCombo)
                .withConverter(new StringToIncidentOriginConverter(incidentOrigins))
                .withValidator(Objects::nonNull, "Incident origin cannot be null")
                .bind(Incident::getOrigin, Incident::setOrigin);


        Button saveButton = Buttons.getSaveButton("Save", e -> {
            binder.setValidatorsDisabled(false);
            binder.validate();
            if (binder.writeBeanIfValid(item)) {
                item.setLastModified(LocalDateTime.now());
                item.setLastModifiedBy(userId);
                saveHandler.accept(item);
                dialog.close();
            } else {
                Notifications.showErrorNotification("Please fill out all required fields");
            }
        });

        Button cancelButton = Buttons.getCancelButton("Cancel", e -> {
            closeHandler.run();
            dialog.close();
        });

        fieldsLayout.add(incidentSummary, incidentDescription, openDateField, closeDateField, subsystemCombo,
                urgencyCombo, subcauseCombo, applicationTypeCombo, incidentTypeCombo, incidentOriginCombo, saveButton, cancelButton);

        fieldsLayout.setAlignItems(FlexComponent.Alignment.STRETCH);

        dialog.add(fieldsLayout);

        return dialog;
    }

    public static Dialog createIncidentDialog(Integer userId, List<String> subsystems, List<String> urgencies, List<String> subcauses, List<String> applicationTypes,
                                              List<IncidentType> incidentTypes, List<IncidentOrigin> incidentOrigins,Consumer<Incident> saveHandler, Runnable closeHandler){
        Dialog dialog = new Dialog();
        dialog.setHeaderTitle("New Incident");

        dialog.setWidth("30%");

        VerticalLayout fieldsLayout = new VerticalLayout();
        fieldsLayout.setWidthFull();

        TextField incidentSummary = new TextField("Summary");
        TextArea incidentDescription = new TextArea("Description");

        ComboBox<String> subsystemCombo = new ComboBox<>("Subsystem");
        subsystemCombo.setItems(subsystems);

        ComboBox<String> urgencyCombo = new ComboBox<>("Urgency");
        urgencyCombo.setItems(urgencies);

        ComboBox<String> subcauseCombo = new ComboBox<>("Subcause");
        subcauseCombo.setItems(subcauses);

        ComboBox<String> applicationTypeCombo = new ComboBox<>("Application type");
        applicationTypeCombo.setItems(applicationTypes);

        ComboBox<String> incidentTypeCombo = new ComboBox<>("Incident Type");
        incidentTypeCombo.setItems(incidentTypes.stream().map(IncidentType::getName).toList());

        ComboBox<String> incidentOriginCombo = new ComboBox<>("Origin");
        incidentOriginCombo.setItems(incidentOrigins.stream().map(IncidentOrigin::getName).toList());

        Incident incident = new Incident();
        Binder<Incident> binder = new Binder<>(Incident.class);
        binder.setBean(incident);
        binder.setValidatorsDisabled(true);

        binder.forField(incidentSummary)
                .asRequired("Summary is required")
                .bind(Incident::getProblemSummary, Incident::setProblemSummary);

        binder.forField(incidentDescription)
                .asRequired("Description is required")
                .bind(Incident::getProblemDescription, Incident::setProblemDescription);

        binder.forField(subsystemCombo)
                .asRequired("Subsystem cannot be blank")
                .bind(Incident::getSubsystem, Incident::setSubsystem);

        binder.forField(urgencyCombo)
                .asRequired("Urgency cannot be blank")
                .bind(Incident::getUrgency, Incident::setUrgency);

        binder.forField(subcauseCombo)
                .asRequired("Subcause cannot be blank")
                .bind(Incident::getSubcause, Incident::setSubcause);

        binder.forField(applicationTypeCombo)
                .asRequired("Application type cannot be blank")
                .bind(Incident::getApplicationType, Incident::setApplicationType);

        binder.forField(incidentTypeCombo)
                .withConverter(new StringToIncidentTypeConverter(incidentTypes))
                .withValidator(Objects::nonNull, "Incident type cannot be null")
                .bind(Incident::getIncidentType, Incident::setIncidentType);

        binder.forField(incidentOriginCombo)
                .withConverter(new StringToIncidentOriginConverter(incidentOrigins))
                .withValidator(Objects::nonNull, "Incident origin cannot be null")
                .bind(Incident::getOrigin, Incident::setOrigin);


        Button saveButton = Buttons.getSaveButton("Save", e -> {
            binder.setValidatorsDisabled(false);
            binder.validate();
            if (binder.writeBeanIfValid(incident)) {
                incident.setCreated(LocalDateTime.now());
                incident.setLastModified(LocalDateTime.now());
                incident.setLastModifiedBy(userId);
                saveHandler.accept(incident);
                dialog.close();
            } else {
                Notifications.showErrorNotification("Please fill out all required fields");
            }
        });


        Button cancelButton = Buttons.getCancelButton("Cancel", e -> {
            closeHandler.run();
            dialog.close();
        });

        fieldsLayout.add(incidentSummary, incidentDescription, subsystemCombo,
                urgencyCombo, subcauseCombo, incidentTypeCombo, incidentOriginCombo, applicationTypeCombo, saveButton, cancelButton);

        fieldsLayout.setAlignItems(FlexComponent.Alignment.STRETCH);

        dialog.add(fieldsLayout);

        return dialog;
    }



}
