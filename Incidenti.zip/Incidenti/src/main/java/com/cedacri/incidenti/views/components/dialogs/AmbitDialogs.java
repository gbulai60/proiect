package com.cedacri.incidenti.views.components.dialogs;

import com.cedacri.incidenti.model.IncidentAmbit;
import com.cedacri.incidenti.utils.ConstraintMessages;
import com.cedacri.incidenti.views.components.Buttons;
import com.cedacri.incidenti.views.components.Notifications;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.Binder;
import jakarta.validation.constraints.NotNull;

import java.util.function.Consumer;

public class AmbitDialogs {

    public static Dialog editAmbitDialog(IncidentAmbit item, Consumer<IncidentAmbit> saveHandler, Runnable closeHandler){

        Dialog dialog = new Dialog();
        dialog.setHeaderTitle("Edit ambit");
        dialog.setWidth("30%");

        return getDialog(item, saveHandler, closeHandler, dialog);
    }

    public static Dialog createAmbitDialog(Consumer<IncidentAmbit> saveHandler, Runnable closeHandler){
        Dialog dialog = new Dialog();
        dialog.setHeaderTitle("New Ambit");
        dialog.setWidth("30%");

        IncidentAmbit ambit = new IncidentAmbit();

        return getDialog(ambit, saveHandler, closeHandler, dialog);

    }

    @NotNull
    private static Dialog getDialog(IncidentAmbit item, Consumer<IncidentAmbit> saveHandler, Runnable closeHandler, Dialog dialog) {
        TextField ambitNameField = new TextField("Name");
        if(item.getName() != null){
            ambitNameField.setValue(item.getName());
        }

        Binder<IncidentAmbit> binder = new Binder<>(IncidentAmbit.class);
        binder.setBean(item);
        binder.setValidatorsDisabled(true);

        binder.forField(ambitNameField)
                .asRequired("Ambit name cannot be blank")
                .bind(IncidentAmbit::getName, IncidentAmbit::setName);

        Button saveButton = Buttons.getSaveButton("Save", e -> {
            binder.setValidatorsDisabled(false);
            binder.validate();
            if(binder.writeBeanIfValid(item)){
                saveHandler.accept(item);
                dialog.close();
            }
            else {
                Notifications.showErrorNotification(ConstraintMessages.FILL_OUT_FIELDS_MESSAGE);
            }
        });

        Button cancelButton = Buttons.getCancelButton("Discard", e -> {
            closeHandler.run();
            dialog.close();
        });

        VerticalLayout fieldsLayout = new VerticalLayout(ambitNameField, saveButton, cancelButton);
        fieldsLayout.setAlignItems(FlexComponent.Alignment.STRETCH);
        dialog.add(fieldsLayout);

        return dialog;
    }
}
