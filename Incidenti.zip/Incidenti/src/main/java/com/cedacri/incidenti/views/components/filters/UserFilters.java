package com.cedacri.incidenti.views.components.filters;

import com.cedacri.incidenti.model.Role;
import com.cedacri.incidenti.model.User;
import com.cedacri.incidenti.service.RoleService;
import com.cedacri.incidenti.views.components.Buttons;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.Text;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.checkbox.CheckboxGroup;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.FlexLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.theme.lumo.LumoUtility;
import jakarta.persistence.criteria.*;
import lombok.NonNull;
import org.springframework.data.jpa.domain.Specification;

import java.util.ArrayList;
import java.util.List;

public class UserFilters extends Div implements Specification<User> {

    private final TextField name = new TextField("Full name");

    private final DatePicker startDate = new DatePicker("Created date");

    private final DatePicker endDate = new DatePicker();

    private final CheckboxGroup<String> roles = new CheckboxGroup<>("Roles");

    private final Runnable onSearch;

    public UserFilters(Runnable onSearch, RoleService roleService) {
        this.onSearch = onSearch;

        setWidthFull();
        addClassName("filter-layout");
        addClassNames(LumoUtility.Padding.Horizontal.LARGE, LumoUtility.Padding.Vertical.MEDIUM,
                LumoUtility.BoxSizing.BORDER);
        name.setPlaceholder("First or last name");
        roles.setItems(roleService.findAll().stream().map(Role::getName).toList());
        roles.addClassName("double-width");

        Button resetBtn = Buttons.getResetFiltersButton("Reset", e -> resetFilters());

        Div actions = new Div(resetBtn, Buttons.getSearchBtn(onSearch));
        actions.addClassName(LumoUtility.Gap.SMALL);
        actions.addClassName("actions");
        add(name, createDateRangeFilter(), roles, actions);
    }

    private void resetFilters() {
        name.clear();
        startDate.clear();
        endDate.clear();
        roles.clear();
        onSearch.run();
    }

    private Component createDateRangeFilter() {
        startDate.setPlaceholder("From");
        endDate.setPlaceholder("To");
        startDate.setAriaLabel("From date");
        endDate.setAriaLabel("To date");

        FlexLayout dateRangeComponent = new FlexLayout(startDate, new Text(" – "), endDate);
        dateRangeComponent.setAlignItems(FlexComponent.Alignment.BASELINE);
        dateRangeComponent.addClassName(LumoUtility.Gap.XSMALL);

        return dateRangeComponent;
    }

    @Override
    public Predicate toPredicate(@NonNull Root<User> root, @NonNull CriteriaQuery<?> query, @NonNull CriteriaBuilder criteriaBuilder) {
        List<Predicate> predicates = new ArrayList<>();

        if (!name.isEmpty()) {
            String lowerCaseFilter = name.getValue().toLowerCase();
            Predicate fullName = criteriaBuilder.like(criteriaBuilder.lower(root.get("fullName")),
                    lowerCaseFilter + "%");
            predicates.add(criteriaBuilder.or(fullName));
        }

        if (startDate.getValue() != null) {
            String databaseColumn = "created";
            predicates.add(criteriaBuilder.greaterThanOrEqualTo(root.get(databaseColumn),
                    criteriaBuilder.literal(startDate.getValue().atStartOfDay())));
        }

        if (endDate.getValue() != null) {
            String databaseColumn = "created";
            predicates.add(criteriaBuilder.greaterThanOrEqualTo(criteriaBuilder.literal(endDate.getValue().atTime(23, 59, 59)),
                    root.get(databaseColumn)));
        }

        if (!roles.isEmpty()) {
            String databaseColumn = "roles";
            List<Predicate> rolePredicates = new ArrayList<>();
            Join<User, Role> rolesJoin = root.joinSet(databaseColumn);

            for (String role : roles.getValue()) {
                rolePredicates.add(criteriaBuilder.equal(rolesJoin.get("name"), role));
            }
            predicates.add(criteriaBuilder.or(rolePredicates.toArray(Predicate[]::new)));
        }
        return criteriaBuilder.and(predicates.toArray(Predicate[]::new));
    }
}