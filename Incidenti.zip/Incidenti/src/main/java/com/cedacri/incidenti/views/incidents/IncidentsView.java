package com.cedacri.incidenti.views.incidents;

import com.cedacri.incidenti.model.Incident;
import com.cedacri.incidenti.model.IncidentOrigin;
import com.cedacri.incidenti.model.IncidentType;
import com.cedacri.incidenti.security.AuthenticatedUser;
import com.cedacri.incidenti.service.IncidentOriginService;
import com.cedacri.incidenti.service.IncidentService;
import com.cedacri.incidenti.service.IncidentTypeService;
import com.cedacri.incidenti.service.UserService;
import com.cedacri.incidenti.views.MainLayout;
import com.cedacri.incidenti.views.components.Buttons;
import com.cedacri.incidenti.views.components.dialogs.Dialogs;
import com.cedacri.incidenti.views.components.Layouts;
import com.cedacri.incidenti.views.components.Notifications;
import com.cedacri.incidenti.views.components.filters.IncidentFilters;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.confirmdialog.ConfirmDialog;
import com.vaadin.flow.component.dependency.Uses;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.spring.data.VaadinSpringDataHelpers;
import com.vaadin.flow.theme.lumo.LumoUtility;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.security.RolesAllowed;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.core.context.SecurityContextHolder;


@PageTitle("Incidents")
@Route(value = "incidents", layout = MainLayout.class)
@RolesAllowed({"ADMIN", "MANAGER"})
@Uses(Icon.class)
public class IncidentsView extends Div {
    private Grid<Incident> grid;
    private final IncidentFilters filters;
    private final IncidentService incidentService;
    private final IncidentOriginService originService;
    private final IncidentTypeService typeService;
    private final UserService userService;

    private final AuthenticatedUser authenticatedUser;

    @Value("#{'${subsystem.options}'.split(',')}")
    private List<String> subsystems;
    @Value("#{'${subcause.options}'.split(',')}")
    private List<String> subcauses;
    @Value("#{'${urgency.options}'.split(',')}")
    private List<String> urgencies;
    @Value("#{'${applicationtype.options}'.split(',')}")
    private List<String> applicationTypes;

    @PostConstruct
    public void init() {
        filters.getSubsystemFilter().setItems(subsystems);
        filters.getSubcauseFilter().setItems(subcauses);
        filters.getUrgencyFilter().setItems(urgencies);
        filters.getApplicationTypeFilter().setItems(applicationTypes);
    }

    public IncidentsView(IncidentService incidentService, IncidentOriginService originService, IncidentTypeService typeService, UserService userService, AuthenticatedUser authenticatedUser) {
        this.incidentService = incidentService;
        this.originService = originService;
        this.typeService = typeService;
        this.userService = userService;
        this.authenticatedUser = authenticatedUser;
        setSizeFull();
        addClassNames("dashboard-view");

        filters = new IncidentFilters(this::refreshGrid, originService, typeService);
        VerticalLayout layout = new VerticalLayout(Layouts.getMobileFilters(filters), filters, createGrid());
        layout.setSizeFull();
        layout.setPadding(false);
        layout.setSpacing(false);
        add(layout);
    }

    private HorizontalLayout createComponentButtonsLayout(Incident item) {
        Button editButton = Buttons.getEditButton(e -> openEditDialog(item));
        Button deleteButton = Buttons.getDeleteButton(e -> openDeleteDialog(item.getId()));

        return Layouts.getActionsLayout(editButton, deleteButton);
    }

    private HorizontalLayout createCloseButtonComponentLayout(Incident item) {
        Button closeButton = Buttons.getCloseIncidentButton(e -> closeIncident(item.getId()));

        HorizontalLayout closeLayout = new HorizontalLayout(closeButton);
        closeLayout.setSizeFull();
        closeLayout.setAlignItems(FlexComponent.Alignment.CENTER);

        return closeLayout;
    }

    private Component createGrid() {
        Grid<Incident> grid = createIncidentsGrid();
        grid.addThemeVariants(GridVariant.LUMO_COLUMN_BORDERS);
        grid.addClassNames(LumoUtility.Border.TOP, LumoUtility.BorderColor.CONTRAST_10);
        return createIncidentsGrid();
    }

    private Grid<Incident> createIncidentsGrid() {
        grid = new Grid<>(Incident.class, false);
        grid.addColumn("id").setHeader("ID").setAutoWidth(true);
        grid.addColumn("createdBy").setHeader("Created By").setAutoWidth(true);
        grid.addColumn("created").setHeader("Created Date").setAutoWidth(true);
        grid.addColumn("openDate").setHeader("Open date").setAutoWidth(true);
        grid.addColumn("closeDate").setHeader("Close date").setAutoWidth(true);
        grid.addColumn("lastModifiedBy").setHeader("Last modified by").setAutoWidth(true);
        grid.addColumn("lastModified").setHeader("Last modified date").setAutoWidth(true);
        grid.addColumn("applicationType").setHeader("Applcication type").setAutoWidth(true);
        grid.addColumn("urgency").setHeader("Urgency").setAutoWidth(true);
        grid.addColumn("subcause").setHeader("Subcause").setAutoWidth(true);
        grid.addColumn(incident -> incident.getOrigin().getName()).setHeader("Origin").setAutoWidth(true);
        grid.addColumn(incident -> incident.getIncidentType().getName()).setHeader("Incident Type").setAutoWidth(true);
        grid.addColumn("subsystem").setHeader("Subsystem").setAutoWidth(true);
        grid.addColumn("problemSummary").setHeader("Summary").setAutoWidth(true);
        grid.addColumn("problemDescription").setHeader("Description").setAutoWidth(true);
        grid.addColumn("requestNumber").setHeader("Request number").setAutoWidth(true);
        if (authenticatedUser.get().isPresent()) {
            boolean isAdmin = authenticatedUser.get().get().getRoles().stream()
                    .anyMatch(role -> role.getName().equalsIgnoreCase("admin"));
            if (isAdmin) {
                grid.addComponentColumn(this::createComponentButtonsLayout).setHeader("Actions").setWidth("15%").setFlexGrow(0);
            }
        }
        grid.addComponentColumn(this::createCloseButtonComponentLayout).setHeader("Close").setWidth("8%").setFlexGrow(0);

        grid.setItems(query -> incidentService.list(
                PageRequest.of(query.getPage(), query.getPageSize(), VaadinSpringDataHelpers.toSpringDataSort(query)),
                filters).stream());
        return grid;
    }

    private void refreshGrid() {
        grid.setItems(query -> {
            PageRequest pageRequest = PageRequest.of(
                    query.getPage(),
                    query.getPageSize(),
                    VaadinSpringDataHelpers.toSpringDataSort(query)
            );
            return incidentService.list(pageRequest, filters).stream();
        });
    }

    private void openEditDialog(Incident item) {

        List<IncidentType> incidentTypes = typeService.findAll();
        List<IncidentOrigin> origins = originService.findAll();
        Integer userId = userService.getUserByUserName(SecurityContextHolder.getContext().getAuthentication().getName()).getId();

        Dialog editDialog = Dialogs.getEditIncidentDialog(userId, item, subsystems, urgencies, subcauses, applicationTypes,
                incidentTypes, origins, this::saveIncident, this::refreshGrid);
        editDialog.open();
    }

    private void openDeleteDialog(Integer id) {
        ConfirmDialog deleteDialog = Dialogs.getDeleteDialog(id, this::deleteIncident);
        deleteDialog.open();
    }

    private void deleteIncident(Integer id) {
        incidentService.delete(id);
        refreshGrid();
        Notifications.showInfoNotification("Incident deleted successfully!");
    }

    private void closeIncident(Integer id) {
        Optional<Incident> optionalIncident = incidentService.findById(id);
        if (optionalIncident.isPresent()) {
            Incident incident = optionalIncident.get();
            incident.setCloseDate(LocalDateTime.now());
            incidentService.save(incident);
            Notifications.showSuccessNotification("Incident closed successfully!");
        } else {
            Notifications.showErrorNotification("Incident not found in database.");
        }
    }

    private void saveIncident(Incident incident) {
        incidentService.save(incident);
        Notifications.showSuccessNotification("Incident saved successfully");
        refreshGrid();
    }

}
