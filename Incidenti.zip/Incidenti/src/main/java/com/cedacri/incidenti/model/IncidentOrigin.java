package com.cedacri.incidenti.model;

import com.cedacri.incidenti.utils.ConstraintMessages;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@Table(name = "incident_origins")
public class IncidentOrigin {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "name", unique = true)
    @NotBlank(message = ConstraintMessages.INCIDENT_ORIGIN_NAME_NOT_BLANK)
    private String name;

}