package com.cedacri.incidenti.service;

import com.cedacri.incidenti.model.IncidentAmbit;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import java.util.List;
import java.util.Optional;

public interface IncidentAmbitService {

    IncidentAmbit save(IncidentAmbit incidentAmbit);

    IncidentAmbit update(Integer id, IncidentAmbit incidentAmbit);

    Optional<IncidentAmbit> findById(Integer id);

    List<IncidentAmbit> findAll();

    boolean delete(Integer id);

    Page<IncidentAmbit> list(Pageable pageable);

    Page<IncidentAmbit> list(Pageable pageable, Specification<IncidentAmbit> filter);

}
