package com.cedacri.incidenti.views.components.userfields;

import com.vaadin.flow.component.textfield.PasswordField;

public class ConfirmPassword extends PasswordField {

    private static final String ERROR_MESSAGE = "Passwords do not match";

    public ConfirmPassword(String label){
        super(label);
        super.setErrorMessage(ERROR_MESSAGE);
        super.setRequiredIndicatorVisible(true);
    }
}
