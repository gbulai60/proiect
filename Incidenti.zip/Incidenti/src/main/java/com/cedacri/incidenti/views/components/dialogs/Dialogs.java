package com.cedacri.incidenti.views.components.dialogs;

import com.cedacri.incidenti.model.*;
import com.vaadin.flow.component.confirmdialog.ConfirmDialog;
import com.vaadin.flow.component.dialog.Dialog;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.function.Consumer;

@Component
public class Dialogs {

    /**
     * Common
     */
    public static ConfirmDialog getDeleteDialog(Integer id, Consumer<Integer> deleteHandler) {
        ConfirmDialog dialog = new ConfirmDialog();
        dialog.setHeader("Confirm delete");
        dialog.setText("Are you sure you want to delete record with id: " + id);

        dialog.setRejectable(true);
        dialog.setRejectText("No");

        dialog.setConfirmText("Yes");
        dialog.addConfirmListener(e -> deleteHandler.accept(id));
        return dialog;
    }

    /**
     * Origins
     */
    public static Dialog getEditOriginDialog(IncidentOrigin item, Consumer<IncidentOrigin> saveHandler, Runnable closeHandler) {
        return OriginDialogs.editOriginDialog(item, saveHandler, closeHandler);
    }

    public static Dialog getCreateOriginDialog(Consumer<IncidentOrigin> saveHandler, Runnable closeHandler) {
        return OriginDialogs.createOriginDialog(saveHandler, closeHandler);
    }

    /**
     * Types
     */
    public static Dialog getEditTypeDialog(IncidentType item, List<IncidentAmbit> ambits, Consumer<IncidentType> saveHandler, Runnable closeHandler) {
        return TypeDialogs.editTypeDialog(item, ambits, saveHandler, closeHandler);
    }

    public static Dialog getCreateTypeDialog(List<IncidentAmbit> ambits, Consumer<IncidentType> saveHandler, Runnable closeHandler) {
        return TypeDialogs.createTypeDialog(ambits, saveHandler, closeHandler);
    }

    /**
     * Ambits
     */
    public static Dialog getEditAmbitDialog(IncidentAmbit item, Consumer<IncidentAmbit> saveHandler, Runnable closeHandler) {
        return AmbitDialogs.editAmbitDialog(item, saveHandler, closeHandler);
    }

    public static Dialog getCreateAmbitDialog(Consumer<IncidentAmbit> saveHandler, Runnable closeHandler) {
        return AmbitDialogs.createAmbitDialog(saveHandler, closeHandler);
    }


    /**
     * Incidents
     */
    public static Dialog getEditIncidentDialog(Integer userId, Incident item, List<String> subsystems, List<String> urgencies,
                                               List<String> subcauses, List<String> applicationTypes, List<IncidentType> incidentTypes,
                                               List<IncidentOrigin> incidentOrigins, Consumer<Incident> saveHandler, Runnable closeHandler) {
        return IncidentDialogs.editIncidentDialog(userId, item, subsystems, urgencies, subcauses, applicationTypes, incidentTypes, incidentOrigins, saveHandler, closeHandler);
    }

    public static Dialog getCreateIncidentDialog(Integer userId, List<String> subsystems, List<String> urgencies, List<String> subcauses, List<String> applicationTypes,
                                                 List<IncidentType> incidentTypes, List<IncidentOrigin> incidentOrigins, Consumer<Incident> saveHandler, Runnable closeHandler) {
        return IncidentDialogs.createIncidentDialog(userId, subsystems, urgencies, subcauses, applicationTypes, incidentTypes, incidentOrigins, saveHandler, closeHandler);
    }
}
