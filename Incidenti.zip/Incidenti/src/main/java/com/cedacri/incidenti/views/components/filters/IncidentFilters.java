package com.cedacri.incidenti.views.components.filters;

import com.cedacri.incidenti.model.Incident;
import com.cedacri.incidenti.model.IncidentOrigin;
import com.cedacri.incidenti.model.IncidentType;
import com.cedacri.incidenti.service.IncidentOriginService;
import com.cedacri.incidenti.service.IncidentTypeService;
import com.cedacri.incidenti.views.components.Buttons;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.theme.lumo.LumoUtility;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import lombok.Getter;
import lombok.NonNull;
import lombok.Setter;
import org.springframework.data.jpa.domain.Specification;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Getter
@Setter
public class IncidentFilters extends Div implements Specification<Incident> {

    private final DatePicker openDateFromFilter = new DatePicker("from ");
    private final DatePicker openDateToFilter = new DatePicker("to");
    private final ComboBox<String> originFilter = new ComboBox<>("Origin");
    private final ComboBox<String> incidentTypeFilter = new ComboBox<>("Incident Type");
    private ComboBox<String> urgencyFilter = new ComboBox<>("Urgency");
    private ComboBox<String> subsystemFilter = new ComboBox<>("Subsystem");
    private ComboBox<String> subcauseFilter = new ComboBox<>("Subcause");
    private ComboBox<String> applicationTypeFilter = new ComboBox<>("Application Type");
    private final Runnable onSearch;

    public IncidentFilters(Runnable onSearch, IncidentOriginService originService, IncidentTypeService typeService) {
        this.onSearch = onSearch;

        setWidthFull();
        addClassName("filter-layout");
        addClassNames(LumoUtility.Padding.Horizontal.LARGE, LumoUtility.Padding.Vertical.MEDIUM,
                LumoUtility.BoxSizing.BORDER);

        originFilter.setItems(originService.findAll()
                .stream()
                .map(IncidentOrigin::getName)
                .collect(Collectors.toList()));

        incidentTypeFilter.setItems(typeService.findAll()
                .stream()
                .map(IncidentType::getName)
                .collect(Collectors.toList()));


        Button resetBtn = Buttons.getResetFiltersButton("Reset", e -> resetFilters());

        Div actions = new Div(resetBtn, Buttons.getSearchBtn(onSearch));
        actions.addClassName(LumoUtility.Gap.SMALL);
        actions.addClassName("actions");

        add(openDateFromFilter, openDateToFilter, subsystemFilter, urgencyFilter, subcauseFilter, originFilter, incidentTypeFilter, applicationTypeFilter, actions);
    }

    private void resetFilters() {
        openDateFromFilter.clear();
        openDateToFilter.clear();
        subsystemFilter.clear();
        urgencyFilter.clear();
        subcauseFilter.clear();
        applicationTypeFilter.clear();
        originFilter.clear();
        incidentTypeFilter.clear();
        onSearch.run();
    }

    @Override
    public Predicate toPredicate(@NonNull Root<Incident> root, @NonNull CriteriaQuery<?> query, @NonNull CriteriaBuilder builder) {
        List<Predicate> predicates = new ArrayList<>();

        if (openDateFromFilter.getValue() != null) {
            predicates.add(builder.greaterThanOrEqualTo(root.get("openDate"), openDateFromFilter.getValue().atStartOfDay()));
        }
        if (openDateToFilter.getValue() != null) {
            predicates.add(builder.lessThanOrEqualTo(root.get("openDate"), openDateToFilter.getValue().atTime(23, 59, 59)));
        }
        if (!urgencyFilter.isEmpty()) {
            predicates.add(builder.like(builder.lower(root.get("urgency")), urgencyFilter.getValue()));
        }
        if (!subsystemFilter.isEmpty()) {
            predicates.add(builder.like(builder.lower(root.get("subsystem")), subsystemFilter.getValue()));
        }
        if (!originFilter.isEmpty()) {
            predicates.add(builder.equal(root.join("origin").get("name"), originFilter.getValue()));
        }
        if (!incidentTypeFilter.isEmpty()) {
            predicates.add(builder.equal(root.join("incidentType").get("name"), incidentTypeFilter.getValue()));
        }
        if (!subcauseFilter.isEmpty()) {
            predicates.add(builder.like(builder.lower(root.get("subcause")), subcauseFilter.getValue()));
        }
        if (!applicationTypeFilter.isEmpty()) {
            predicates.add(builder.like(builder.lower(root.get("applicationType")), applicationTypeFilter.getValue()));
        }
        return builder.and(predicates.toArray(Predicate[]::new));
       }
}