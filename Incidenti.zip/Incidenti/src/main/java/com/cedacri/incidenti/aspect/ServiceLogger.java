package com.cedacri.incidenti.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class ServiceLogger {

    private static final Logger logger = LoggerFactory.getLogger(ServiceLogger.class);

    @Pointcut("execution(* com.cedacri.incidenti.service.*.*(..))")
    public void servicePointcut(){

    }

    @Before("servicePointcut()")
    public void logBeforeService(JoinPoint joinPoint){
        logger.debug("Executing |" + joinPoint.getSignature().getName() + "|");
    }

    @AfterReturning(pointcut = "servicePointcut()", returning = "result")
    public void logAfterServiceReturnsValue(JoinPoint joinPoint, Object result){
        logger.debug("|" + joinPoint.getSignature().getName() + "|" + " returned -> " + result);
    }

    @AfterThrowing(pointcut = "servicePointcut()", throwing = "error")
    public void logAfterThrowingExceptionInServiceMethods(JoinPoint joinPoint, Throwable error){
        logger.error("|" + joinPoint.getSignature().getName() + "| throws exception: \n" + error.getMessage() );
    }

    @After("servicePointcut()")
    public void logAfterAllServices(JoinPoint joinPoint){
        logger.debug("|" + joinPoint.getSignature().getName() + "| executed");
    }
}
