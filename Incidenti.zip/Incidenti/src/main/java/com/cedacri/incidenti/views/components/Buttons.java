package com.cedacri.incidenti.views.components;

import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;

public class Buttons {

    private static final String editButtonTextValue = "Edit";

    private static final String deleteButtonTextValue = "Delete";

    public static Button getSearchBtn(Runnable onSearch) {
        Button searchButton = new Button("Search");
        searchButton.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
        searchButton.addClickListener(e -> onSearch.run());
        return searchButton;
    }

    public static Button getCancelButton(String message, ComponentEventListener<ClickEvent<Button>> clickListener) {
        Button cancelButton = new Button(message);
        cancelButton.addThemeVariants(ButtonVariant.LUMO_TERTIARY);
        cancelButton.addClickListener(clickListener);
        return cancelButton;
    }

    public static Button getEditButton(ComponentEventListener<ClickEvent<Button>> clickListener) {
        Button editButton = new Button(editButtonTextValue);
        editButton.addClassName("edit-button");
        editButton.addClickListener(clickListener);
        return editButton;
    }

    public static Button getDeleteButton(ComponentEventListener<ClickEvent<Button>> clickListener) {
        Button deleteButton = new Button(deleteButtonTextValue);
        deleteButton.addClassName("delete-button");
        deleteButton.addClickListener(clickListener);
        return deleteButton;
    }

    public static Button getSaveButton(String message, ComponentEventListener<ClickEvent<Button>> clickListener) {
        Button saveButton = new Button(message);
        saveButton.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
        saveButton.addClickListener(clickListener);
        return saveButton;
    }

    public static Button getAddButton(String message, ComponentEventListener<ClickEvent<Button>> clickListener) {
        Button addButton = new Button(message);
        addButton.addClickListener(clickListener);
        return addButton;
    }

    public static Button getResetFiltersButton(String message, ComponentEventListener<ClickEvent<Button>> clickListener) {
        Button resetButton = new Button(message);
        resetButton.addClickListener(clickListener);
        resetButton.addThemeVariants(ButtonVariant.LUMO_TERTIARY);
        return resetButton;
    }

    public static Button getCloseIncidentButton(ComponentEventListener<ClickEvent<Button>> clickListener) {
        Button closeButton = new Button("Close");
        closeButton.addClickListener(clickListener);
        return closeButton;
    }

}
