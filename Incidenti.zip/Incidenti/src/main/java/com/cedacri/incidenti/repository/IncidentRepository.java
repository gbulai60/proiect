package com.cedacri.incidenti.repository;

import com.cedacri.incidenti.model.Incident;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IncidentRepository extends JpaRepository<Incident,Integer> {
    Page<Incident> findAll(Specification<Incident> spec, Pageable pageable);
}
