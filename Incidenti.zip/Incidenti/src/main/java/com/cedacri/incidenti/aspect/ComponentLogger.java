package com.cedacri.incidenti.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class ComponentLogger {

    private static final Logger logger = LoggerFactory.getLogger(ComponentLogger.class);

    @Pointcut("execution(* com.cedacri.incidenti.views.components.*.*(..))")
    public void componentPointcut(){

    }

    @Before("componentPointcut()")
    public void logBeforeComponent(JoinPoint joinPoint){
        logger.debug("Executing |" + joinPoint.getSignature().getName() + "|");
    }

    @AfterReturning(pointcut = "componentPointcut()", returning = "result")
    public void logAfterComponentReturnsValue(JoinPoint joinPoint, Object result){
        logger.debug("|" + joinPoint.getSignature().getName() + "|" + " returned -> " + result);
    }

    @AfterThrowing(pointcut = "componentPointcut()", throwing = "error")
    public void logAfterThrowingExceptionInComponentMethods(JoinPoint joinPoint, Throwable error){
        logger.error("|" + joinPoint.getSignature().getName() + "| throws exception: \n" + error.getMessage() );
    }

    @After("componentPointcut()")
    public void logAfterAllComponents(JoinPoint joinPoint){
        logger.debug("|" + joinPoint.getSignature().getName() + "| executed");
    }
}
