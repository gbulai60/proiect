package com.cedacri.incidenti.service.implementation;

import com.cedacri.incidenti.model.Incident;
import com.cedacri.incidenti.repository.IncidentRepository;
import com.cedacri.incidenti.service.IncidentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class IncidentServiceImpl implements IncidentService {

    private final IncidentRepository incidentRepository;

    @Autowired
    public IncidentServiceImpl(IncidentRepository incidentRepository) {
        this.incidentRepository = incidentRepository;
    }

    @Override
    @Transactional
    public Incident save(Incident incident) {
        return incidentRepository.save(incident);
    }

    @Override
    public Incident update(Incident incident) {
        Optional<Incident> existingIncident = incidentRepository.findById(incident.getId());
        if (existingIncident.isPresent()) {
            return incidentRepository.save(incident);
        } else {
            return null;
        }
    }

    @Override
    public Optional<Incident> findById(Integer id) {
        return incidentRepository.findById(id);
    }

    @Override
    public List<Incident> findAll() {
        return incidentRepository.findAll();
    }

    @Override
    public boolean delete(Integer id) {
        Optional<Incident> optionalIncident = incidentRepository.findById(id);
        if (optionalIncident.isPresent()) {
            incidentRepository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public Page<Incident> list(Pageable pageable) {
        return incidentRepository.findAll(pageable);
    }

    @Override
    public Page<Incident> list(Pageable pageable, Specification<Incident> filter) {
        return incidentRepository.findAll(filter, pageable);
    }
}
