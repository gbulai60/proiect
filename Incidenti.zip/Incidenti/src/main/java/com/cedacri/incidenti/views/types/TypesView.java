package com.cedacri.incidenti.views.types;


import com.cedacri.incidenti.model.IncidentAmbit;
import com.cedacri.incidenti.model.IncidentType;
import com.cedacri.incidenti.service.IncidentAmbitService;
import com.cedacri.incidenti.service.IncidentTypeService;
import com.cedacri.incidenti.views.MainLayout;
import com.cedacri.incidenti.views.components.Buttons;
import com.cedacri.incidenti.views.components.Layouts;
import com.cedacri.incidenti.views.components.Notifications;
import com.cedacri.incidenti.views.components.dialogs.Dialogs;
import com.cedacri.incidenti.views.components.filters.TypeFilters;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.confirmdialog.ConfirmDialog;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.spring.data.VaadinSpringDataHelpers;
import com.vaadin.flow.theme.lumo.LumoUtility;
import jakarta.annotation.security.RolesAllowed;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;

@PageTitle("Types")
@Route(value = "types", layout = MainLayout.class)
@RolesAllowed("ADMIN")
public class TypesView extends Div {
    private Grid<IncidentType> grid;

    private final TypeFilters filters;

    private final IncidentTypeService typeService;
    private final IncidentAmbitService ambitService;
    private final Button createTypeButton;

    @Autowired
    public TypesView(IncidentTypeService typeService, IncidentAmbitService ambitService) {
        this.typeService = typeService;
        this.ambitService = ambitService;
        setSizeFull();
        addClassNames("types-view");
        filters = new TypeFilters(this::refreshGrid, ambitService);
        createTypeButton = Buttons.getAddButton("Create new type", e -> openCreateDialog());

        VerticalLayout layout = new VerticalLayout(Layouts.getMobileFilters(filters), filters, createButtonsLayout(), createGrid());
        layout.setSizeFull();
        layout.setPadding(false);
        layout.setSpacing(false);
        add(layout);
    }

    private HorizontalLayout createButtonsLayout(){
        return Layouts.getButtonsLayout(createTypeButton);
    }

    private HorizontalLayout createComponentButtonsLayout(IncidentType item){
        Button editButton = Buttons.getEditButton(e -> openEditDialog(item));
        Button deleteButton = Buttons.getDeleteButton(e -> openDeleteDialog(item.getId()));

        return Layouts.getActionsLayout(editButton, deleteButton);
    }

    private Component createGrid() {
        Grid<IncidentType> grid = createTypeGrid();
        grid.addThemeVariants(GridVariant.LUMO_NO_BORDER);
        grid.addClassNames(LumoUtility.Border.TOP, LumoUtility.BorderColor.CONTRAST_10);
        return grid;
    }

    private Grid<IncidentType> createTypeGrid(){
        grid = new Grid<>(IncidentType.class, false);
        grid.addColumn("id").setAutoWidth(true).setHeader("Id");
        grid.addColumn("name").setAutoWidth(true).setHeader("Name");
        grid.addColumn(item -> item.getAmbit().getName()).setAutoWidth(true).setHeader("Ambit");
        grid.addComponentColumn(this::createComponentButtonsLayout).setHeader("Actions");
        grid.setItems(query -> typeService.list(
                PageRequest.of(query.getPage(), query.getPageSize(), VaadinSpringDataHelpers.toSpringDataSort(query)),
                filters).stream());
        return grid;
    }

    private void refreshGrid() {
        grid.getDataProvider().refreshAll();
    }

    private void openEditDialog(IncidentType item){
        List<IncidentAmbit> ambits = ambitService.findAll();

        Dialog editDialog = Dialogs.getEditTypeDialog(item, ambits, this::saveType, this::refreshGrid);
        editDialog.open();
    }

    private void openCreateDialog(){

        List<IncidentAmbit> ambits = ambitService.findAll();

        Dialog dialog = Dialogs.getCreateTypeDialog(ambits, this::saveType, this::refreshGrid);
        dialog.open();
    }

    private void openDeleteDialog(Integer id){
        ConfirmDialog deleteDialog = Dialogs.getDeleteDialog(id, this::deleteType);
        deleteDialog.open();
    }

    private void saveType(IncidentType type){
        typeService.save(type);
        Notifications.showSuccessNotification("Type saved successfuly");
        refreshGrid();
    }

    private void deleteType(Integer id){
        typeService.delete(id);
        Notifications.showSuccessNotification("Type deleted successfuly");
        refreshGrid();
    }
}
