package com.cedacri.incidenti.service.implementation;

import com.cedacri.incidenti.model.IncidentType;
import com.cedacri.incidenti.repository.IncidentTypeRepository;
import com.cedacri.incidenti.service.IncidentTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class IncidentTypeServiceImpl implements IncidentTypeService {

    private final IncidentTypeRepository incidentTypeRepository;

    @Autowired
    public IncidentTypeServiceImpl(IncidentTypeRepository incidentTypeRepository) {
        this.incidentTypeRepository = incidentTypeRepository;
    }

    @Override
    @Transactional
    public IncidentType save(IncidentType incidentType) {
        return incidentTypeRepository.save(incidentType);
    }

    @Override
    public IncidentType update(Integer id, IncidentType incidentType) {
        Optional<IncidentType> existingType = incidentTypeRepository.findById(id);
        if (existingType.isPresent()) {
            IncidentType updatedIncidentType = existingType.get();
            updatedIncidentType.setName(incidentType.getName());
            updatedIncidentType.setAmbit(incidentType.getAmbit());
            incidentTypeRepository.save(updatedIncidentType);
            return updatedIncidentType;
        } else {
            return null;
        }
    }

    @Override
    public Optional<IncidentType> findById(Integer id) {
        return incidentTypeRepository.findById(id);
    }

    @Override
    public List<IncidentType> findAll() {
        return incidentTypeRepository.findAll();
    }

    @Override
    public boolean delete(Integer id) {
        Optional<IncidentType> optionalIncidentType = incidentTypeRepository.findById(id);
        if (optionalIncidentType.isPresent()) {
            incidentTypeRepository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public Page<IncidentType> list(Pageable pageable) {
        return incidentTypeRepository.findAll(pageable);
    }

    @Override
    public Page<IncidentType> list(Pageable pageable, Specification<IncidentType> filter) {
        return incidentTypeRepository.findAll(filter,pageable);
    }
}
