package com.cedacri.incidenti.utils;

public class ConstraintMessages {

    /**User**/
        public static final String USER_USERNAME_IS_REQUIRED = "Username is required";
        public static final String USER_CREATED_BY_NOT_NULL = "Creator ID cannot be null.";

        public static final String USER_CREATED_NOT_NULL = "Creation date cannot be null.";

        public static final String USER_LAST_MODIFIED_BY_NOT_NULL = "Last modified by cannot be null.";

        public static final String USER_USERNAME_NOT_BLANK = "Username cannot be blank.";

        public static final String USER_PASSWORD_NOT_BLANK = "Password cannot be blank";

        public static final String USER_FULL_NAME_NOT_BLANK = "Full name cannot be blank.";

        public static final String USER_FULL_NAME_PATTERN = "Full name is not valid. It must start with a capital letter and follow the format 'Firstname Lastname'.";

        public static final String USER_EMAIL_NOT_BLANK = "Email cannot be blank.";

        public static final String USER_EMAIL_NOT_VALID = "Email address is not valid.";

        public static final String USER_IS_ENABLED_NOT_NULL = "Is enabled flag must be set.";

        public static final String USER_IS_ENABLED_VALUE = "Is enabled flag must be either 1 (true) or 0 (false).";


        /**Role**/
        public static final String ROLE_IS_REQUIRED = "Role is required field";

        public static final String ROLE_NAME_NOT_BLANK = "Role name should not be null/blank.";

        public static final String ROLE_NAME_SIZE = "Role name should be at least 2 characters long.";

        public static final String ROLE_DESCRIPTION_NOT_BLANK = "Role description should not be null/blank.";


        /**Incident Type**/

        public static final String INCIDENT_TYPE_ID_NOT_BLANK = "Incident type ID should not be null/blank.";

        public static final String INCIDENT_TYPE_NAME_NOT_BLANK = "Incident type name should not be null/blank.";


        /**Incident Origin**/

        public static final String INCIDENT_ORIGIN_ID_NOT_BLANK = "Origin ID should not be null/blank.";

        public static final String INCIDENT_ORIGIN_NAME_NOT_BLANK = "Origin name should not be null/blank.";


        /**Incident Ambit**/

        public static final String INCIDENT_AMBIT_NAME_NOT_BLANK = "Ambit name should not be null/blank.";


        /**Incident**/

        public static final String INCIDENT_LAST_MODIFIED_BY_NOT_BLANK = "Last modified by field can't be null";

        public static final String INCIDENT_LAST_MODIFIED_DATE_NOT_BLANK = "Last modification date can't be null/blank.";

        public static final String INCIDENT_SUBSYSTEM_NOT_BLANK = "Incident subsystem can't be null/blank.";

        public static final String INCIDENT_APPLICATION_TYPE_NOT_BLANK = "Application type cannot be blank.";

        public static final String INCIDENT_URGENCY_NOT_BLANK = "Urgency cannot be blank.";

        public static final String INCIDENT_SUBCAUSE_NOT_BLANK = "Subcause cannot be blank.";

        public static final String INCIDENT_PROBLEM_SUMMARY_NOT_BLANK = "Problem summary cannot be blank.";

        public static final String INCIDENT_PROBLEM_DESCRIPTION_NOT_BLANK = "Problem description cannot be blank.";

        /** Notifications **/

        public static final String FILL_OUT_FIELDS_MESSAGE = "Please fill out all required fields!";


}
