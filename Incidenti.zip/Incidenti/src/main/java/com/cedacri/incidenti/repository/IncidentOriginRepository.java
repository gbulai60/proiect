package com.cedacri.incidenti.repository;

import com.cedacri.incidenti.model.IncidentOrigin;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IncidentOriginRepository extends JpaRepository<IncidentOrigin,Integer> {
    IncidentOrigin findIncidentOriginByName(String name);
    Page<IncidentOrigin> findAll(Specification<IncidentOrigin> spec, Pageable pageable);
}
