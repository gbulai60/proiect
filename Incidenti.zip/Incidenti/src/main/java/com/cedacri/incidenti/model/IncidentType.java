package com.cedacri.incidenti.model;

import com.cedacri.incidenti.utils.ConstraintMessages;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

import java.util.HashSet;
import java.util.Set;

@Entity
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "incident_types")
public class IncidentType {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "name")
    @NotBlank(message = ConstraintMessages.INCIDENT_TYPE_NAME_NOT_BLANK)
    private String name;

    @ManyToOne
    @JoinColumn(name = "ambit_id")
    private IncidentAmbit ambit;
}