package com.cedacri.incidenti.views.components.filters;

import com.cedacri.incidenti.model.IncidentAmbit;
import com.cedacri.incidenti.model.IncidentType;
import com.cedacri.incidenti.service.IncidentAmbitService;
import com.cedacri.incidenti.views.components.Buttons;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.textfield.IntegerField;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.theme.lumo.LumoUtility;
import jakarta.persistence.criteria.*;
import lombok.NonNull;
import org.springframework.data.jpa.domain.Specification;

import java.util.ArrayList;
import java.util.List;

public class TypeFilters extends Div implements Specification<IncidentType> {

    private final IntegerField idFilter = new IntegerField("Id");

    private final TextField nameFilter = new TextField("Name");

    private final ComboBox<String> ambitNameFilter = new ComboBox<>("Ambit");

    public TypeFilters(Runnable onSearch, IncidentAmbitService ambitService) {

        setWidthFull();
        addClassName("filter-layout");
        addClassNames(LumoUtility.Padding.Horizontal.LARGE, LumoUtility.Padding.Vertical.MEDIUM,
                LumoUtility.BoxSizing.BORDER);
        idFilter.setPlaceholder("Id");
        nameFilter.setPlaceholder("Type");
        ambitNameFilter.setPlaceholder("Ambit");

        ambitNameFilter.setItems(ambitService.findAll().stream()
                .map(IncidentAmbit::getName).toList());



        Button resetBtn = new Button("Reset");
        resetBtn.addThemeVariants(ButtonVariant.LUMO_TERTIARY);
        resetBtn.addClickListener(e -> {
            idFilter.clear();
            nameFilter.clear();
            ambitNameFilter.clear();
            onSearch.run();
        });

        Div actions = new Div(resetBtn, Buttons.getSearchBtn(onSearch));
        actions.addClassName(LumoUtility.Gap.SMALL);
        actions.addClassName("actions");

        add(idFilter,nameFilter, ambitNameFilter, actions);
    }


    @Override
    public Predicate toPredicate(@NonNull Root<IncidentType> root, @NonNull CriteriaQuery<?> query, @NonNull CriteriaBuilder criteriaBuilder) {
        List<Predicate> predicates = new ArrayList<>();
        Join<IncidentType, IncidentAmbit> ambitJoin = root.join("ambit");

        if (!idFilter.isEmpty()) {
            Integer typeIdFilter = idFilter.getValue();
            predicates.add(criteriaBuilder.equal(root.get("id"),
                    typeIdFilter ));
        }
        if (!nameFilter.isEmpty()) {
            predicates.add(criteriaBuilder.like(criteriaBuilder.lower(root.get("name")),
                    nameFilter.getValue().toLowerCase() + "%"));
        }
        if (!ambitNameFilter.isEmpty()) {
            predicates.add(criteriaBuilder.like(ambitJoin.get("name"), ambitNameFilter.getValue() + "%"));
        }

        return criteriaBuilder.and(predicates.toArray(Predicate[]::new));
    }
}