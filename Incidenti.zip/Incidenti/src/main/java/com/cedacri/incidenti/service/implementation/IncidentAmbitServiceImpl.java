package com.cedacri.incidenti.service.implementation;

import com.cedacri.incidenti.model.IncidentAmbit;
import com.cedacri.incidenti.repository.IncidentAmbitRepository;
import com.cedacri.incidenti.service.IncidentAmbitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class IncidentAmbitServiceImpl implements IncidentAmbitService {

    private final IncidentAmbitRepository incidentAmbitRepository;

    @Autowired
    public IncidentAmbitServiceImpl(IncidentAmbitRepository incidentAmbitRepository) {
        this.incidentAmbitRepository = incidentAmbitRepository;
    }


    @Override
    @Transactional
    public IncidentAmbit save(IncidentAmbit incidentAmbit) {
        return incidentAmbitRepository.save(incidentAmbit);
    }

    @Override
    public IncidentAmbit update(Integer id, IncidentAmbit incidentAmbit) {
        Optional<IncidentAmbit> existingAmbit = incidentAmbitRepository.findById(id);
        if (existingAmbit.isPresent()) {
            IncidentAmbit ambit = existingAmbit.get();
            ambit.setName(incidentAmbit.getName());
            incidentAmbitRepository.save(ambit);
            return ambit;
        } else {
            return null;
        }
    }

    @Override
    public Optional<IncidentAmbit> findById(Integer id) {
        return incidentAmbitRepository.findById(id);
    }

    @Override
    public List<IncidentAmbit> findAll() {
        return incidentAmbitRepository.findAll().stream().toList();
    }

    @Override
    @Transactional
    public boolean delete(Integer id) {
        Optional<IncidentAmbit> optionalIncidentAmbit = incidentAmbitRepository.findById(id);
        if (optionalIncidentAmbit.isPresent()) {
            incidentAmbitRepository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public Page<IncidentAmbit> list(Pageable pageable) {
        return incidentAmbitRepository.findAll(pageable);
    }

    @Override
    public Page<IncidentAmbit> list(Pageable pageable, Specification<IncidentAmbit> filter) {
        return incidentAmbitRepository.findAll(filter,pageable);
    }

}
