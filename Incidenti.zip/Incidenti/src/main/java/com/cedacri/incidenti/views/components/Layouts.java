package com.cedacri.incidenti.views.components;


import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.theme.lumo.LumoUtility;

public class Layouts {
    public static HorizontalLayout getMobileFilters(Div filters) {
        HorizontalLayout mobileFilters = new HorizontalLayout();
        mobileFilters.setWidthFull();
        mobileFilters.addClassNames(LumoUtility.Padding.MEDIUM, LumoUtility.BoxSizing.BORDER,
                LumoUtility.AlignItems.CENTER);
        mobileFilters.addClassName("mobile-filters");

        Icon mobileIcon = new Icon("lumo", "plus");
        Span filtersHeading = new Span("Filters");
        mobileFilters.add(mobileIcon, filtersHeading);
        mobileFilters.setFlexGrow(1, filtersHeading);
        mobileFilters.addClickListener(e -> {
            if (filters.getClassNames().contains("visible")) {
                filters.removeClassName("visible");
                mobileIcon.getElement().setAttribute("icon", "lumo:plus");
            } else {
                filters.addClassName("visible");
                mobileIcon.getElement().setAttribute("icon", "lumo:minus");
            }
        });
        return mobileFilters;
    }

    public static HorizontalLayout getButtonsLayout(Button addButton) {
        HorizontalLayout buttonsLayout = new HorizontalLayout(addButton);
        buttonsLayout.addClassName("add-layout-container");
        addButton.addClassName("add-button");
        buttonsLayout.setJustifyContentMode(FlexComponent.JustifyContentMode.START);
        return buttonsLayout;
    }

    public static HorizontalLayout getActionsLayout(Button... buttons) {
        HorizontalLayout actionsLayout = new HorizontalLayout(buttons);
        actionsLayout.setJustifyContentMode(FlexComponent.JustifyContentMode.END);
        actionsLayout.setPadding(false);
        actionsLayout.setSizeFull();
        return actionsLayout;
    }
}
