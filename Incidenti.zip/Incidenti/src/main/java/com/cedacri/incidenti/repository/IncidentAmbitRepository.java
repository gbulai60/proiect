package com.cedacri.incidenti.repository;

import com.cedacri.incidenti.model.IncidentAmbit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface IncidentAmbitRepository extends JpaRepository<IncidentAmbit,Integer>, JpaSpecificationExecutor<IncidentAmbit>
{
    Optional<IncidentAmbit> findByName(String name);
}
