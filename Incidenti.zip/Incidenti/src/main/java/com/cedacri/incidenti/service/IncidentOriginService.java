package com.cedacri.incidenti.service;

import com.cedacri.incidenti.model.IncidentOrigin;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import java.util.List;
import java.util.Optional;

public interface IncidentOriginService {
    IncidentOrigin save(IncidentOrigin incidentOrigin);
    IncidentOrigin update(Integer id, IncidentOrigin incidentOrigin);
    Optional<IncidentOrigin> findById(Integer id);
    List<IncidentOrigin> findAll();

    boolean delete(Integer id);
    Page<IncidentOrigin> list(Pageable pageable);
    Page<IncidentOrigin> list(Pageable pageable, Specification<IncidentOrigin> filter);
}
