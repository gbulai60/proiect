package com.cedacri.incidenti.views.dashboard;

import com.cedacri.incidenti.model.Incident;
import com.cedacri.incidenti.model.IncidentOrigin;
import com.cedacri.incidenti.model.IncidentType;
import com.cedacri.incidenti.service.IncidentOriginService;
import com.cedacri.incidenti.service.IncidentService;
import com.cedacri.incidenti.service.IncidentTypeService;
import com.cedacri.incidenti.service.UserService;
import com.cedacri.incidenti.views.MainLayout;
import com.cedacri.incidenti.views.components.Buttons;
import com.cedacri.incidenti.views.components.Notifications;
import com.cedacri.incidenti.views.components.dialogs.Dialogs;
import com.cedacri.incidenti.views.components.Layouts;
import com.cedacri.incidenti.views.components.filters.IncidentFilters;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.Uses;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.router.RouteAlias;
import com.vaadin.flow.spring.data.VaadinSpringDataHelpers;
import com.vaadin.flow.theme.lumo.LumoUtility;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.security.PermitAll;
import java.util.List;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.core.context.SecurityContextHolder;


@PageTitle("Dashboard")
@Route(value = "dashboard", layout = MainLayout.class)
@RouteAlias(value = "", layout = MainLayout.class)
@PermitAll
@Uses(Icon.class)
public class DashboardView extends Div {

    private final Button createIncidentButton;

    private Grid<Incident> grid;

    private final IncidentFilters filters;

    private final IncidentService incidentService;
    private final IncidentTypeService typeService;
    private final IncidentOriginService originService;
    private final UserService userService;

    @Value("#{'${subsystem.options}'.split(',')}")
    private List<String> subsystems;
    @Value("#{'${subcause.options}'.split(',')}")
    private List<String> subcauses;
    @Value("#{'${urgency.options}'.split(',')}")
    private List<String> urgencies;
    @Value("#{'${applicationtype.options}'.split(',')}")
    private List<String> applicationTypes;

    @PostConstruct
    public void init(){
        filters.getSubsystemFilter().setItems(subsystems);
        filters.getSubcauseFilter().setItems(subcauses);
        filters.getUrgencyFilter().setItems(urgencies);
        filters.getApplicationTypeFilter().setItems(applicationTypes);
    }

    public DashboardView(IncidentService incidentService, IncidentOriginService originService, IncidentTypeService typeService, UserService userService) {
        this.incidentService = incidentService;
        this.typeService = typeService;
        this.originService = originService;
        this.userService = userService;
        setSizeFull();
        addClassNames("dashboard-view");

        filters = new IncidentFilters(this::refreshGrid, originService, typeService);

        createIncidentButton = Buttons.getAddButton("Add new incident", e -> openCreateDialog());

        VerticalLayout layout = new VerticalLayout(Layouts.getMobileFilters(filters), filters, createButtonsLayout(), createGrid());
        layout.setSizeFull();
        layout.setPadding(false);
        layout.setSpacing(false);
        add(layout);
    }

    private HorizontalLayout createButtonsLayout(){
        return Layouts.getButtonsLayout(createIncidentButton);
    }

    private void openCreateDialog(){
        List<IncidentType> incidentTypes = typeService.findAll();
        List<IncidentOrigin> origins = originService.findAll();
        Integer userId = userService.getUserByUserName(SecurityContextHolder.getContext().getAuthentication().getName()).getId();
        Dialog dialog = Dialogs.getCreateIncidentDialog(userId, subsystems, urgencies, subcauses, applicationTypes, incidentTypes, origins, this::saveIncident, this::refreshGrid);
        dialog.open();
    }

    private void saveIncident(Incident incident){
        incidentService.save(incident);
        Notifications.showSuccessNotification("Incident saved successfully!");
        refreshGrid();
    }

    private Component createGrid(){
        Grid<Incident> grid = createIncidentsGrid();
        grid.addThemeVariants(GridVariant.LUMO_NO_BORDER);
        grid.addClassNames(LumoUtility.Border.TOP, LumoUtility.BorderColor.CONTRAST_10);
        return grid;
    }

    private Grid<Incident> createIncidentsGrid() {
        grid = new Grid<>(Incident.class, false);
        grid.addColumn("id").setHeader("ID").setAutoWidth(true);
        grid.addColumn("createdBy").setHeader("Created By").setAutoWidth(true);
        grid.addColumn("created").setHeader("Created Date").setAutoWidth(true);
        grid.addColumn("openDate").setHeader("Open date").setAutoWidth(true);
        grid.addColumn("closeDate").setHeader("Close date").setAutoWidth(true);
        grid.addColumn("lastModifiedBy").setHeader("Last modified by").setAutoWidth(true);
        grid.addColumn("lastModified").setHeader("Last modified date").setAutoWidth(true);
        grid.addColumn("applicationType").setHeader("Application type").setAutoWidth(true);
        grid.addColumn("urgency").setHeader("Urgency").setAutoWidth(true);
        grid.addColumn("subcause").setHeader("Subcause").setAutoWidth(true);
        grid.addColumn(incident -> incident.getOrigin().getName()).setHeader("Origin").setAutoWidth(true);
        grid.addColumn(incident -> incident.getIncidentType().getName()).setHeader("Incident Type").setAutoWidth(true);
        grid.addColumn("subsystem").setHeader("Subsystem").setAutoWidth(true);
        grid.addColumn("problemSummary").setHeader("Summary").setAutoWidth(true);
        grid.addColumn("problemDescription").setHeader("Description").setAutoWidth(true);
        grid.addColumn("requestNumber").setHeader("Request number").setAutoWidth(true);

        grid.setItems(query -> incidentService.list(
                PageRequest.of(query.getPage(), query.getPageSize(), VaadinSpringDataHelpers.toSpringDataSort(query)),
                filters).stream());

        return grid;
    }

    private void refreshGrid() {
        grid.setItems(query -> {
            PageRequest pageRequest = PageRequest.of(
                    query.getPage(),
                    query.getPageSize(),
                    VaadinSpringDataHelpers.toSpringDataSort(query)
            );
            return incidentService.list(pageRequest, filters).stream();
        });
    }

}
