package com.cedacri.incidenti.model;

import com.cedacri.incidenti.utils.ConstraintMessages;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "roles")
public class Role {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "name")
    @NotBlank(message = ConstraintMessages.ROLE_NAME_NOT_BLANK)
    @Size(min = 2, message = ConstraintMessages.ROLE_NAME_SIZE)
    private String name;

    @Column(name = "description")
    @NotBlank(message = ConstraintMessages.ROLE_DESCRIPTION_NOT_BLANK)
    private String description;

}
