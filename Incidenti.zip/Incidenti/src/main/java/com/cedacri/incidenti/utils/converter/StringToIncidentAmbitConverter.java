package com.cedacri.incidenti.utils.converter;

import com.cedacri.incidenti.model.IncidentAmbit;
import com.cedacri.incidenti.model.IncidentOrigin;
import com.vaadin.flow.data.binder.Result;
import com.vaadin.flow.data.binder.ValueContext;
import com.vaadin.flow.data.converter.Converter;

import java.util.List;

public class StringToIncidentAmbitConverter implements Converter<String, IncidentAmbit> {

    private List<IncidentAmbit> ambits;

    public StringToIncidentAmbitConverter(List<IncidentAmbit> ambits) {
        this.ambits = ambits;
    }

    @Override
    public Result<IncidentAmbit> convertToModel(String value, ValueContext context) {
        if(value == null){
            return Result.ok(null);
        }

        for(IncidentAmbit ambit : ambits){
            if(ambit.getName().equals(value)){
                return Result.ok(ambit);
            }
        }

        return Result.error("Unknown incident ambit: " + value);
    }

    @Override
    public String convertToPresentation(IncidentAmbit ambit, ValueContext valueContext) {
        return null;
    }
}
