package com.cedacri.incidenti.views;

import com.cedacri.incidenti.model.User;
import com.cedacri.incidenti.security.AuthenticatedUser;
import com.cedacri.incidenti.views.ambits.AmbitsView;
import com.cedacri.incidenti.views.dashboard.DashboardView;
import com.cedacri.incidenti.views.incidents.IncidentsView;
import com.cedacri.incidenti.views.origins.OriginsView;
import com.cedacri.incidenti.views.settings.SettingsView;
import com.cedacri.incidenti.views.types.TypesView;
import com.cedacri.incidenti.views.users.UsersView;
import com.vaadin.flow.component.applayout.AppLayout;
import com.vaadin.flow.component.applayout.DrawerToggle;
import com.vaadin.flow.component.avatar.Avatar;
import com.vaadin.flow.component.contextmenu.MenuItem;
import com.vaadin.flow.component.html.Anchor;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Footer;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.Header;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.menubar.MenuBar;
import com.vaadin.flow.component.orderedlayout.Scroller;
import com.vaadin.flow.component.sidenav.SideNav;
import com.vaadin.flow.component.sidenav.SideNavItem;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.server.auth.AccessAnnotationChecker;
import com.vaadin.flow.theme.lumo.LumoUtility;

import java.util.Optional;

import org.vaadin.lineawesome.LineAwesomeIcon;

/**
 * The main view is a top-level placeholder for other views.
 */
public class MainLayout extends AppLayout {

    private H2 viewTitle;

    private final AuthenticatedUser authenticatedUser;
    private final AccessAnnotationChecker accessChecker;

    public MainLayout(AuthenticatedUser authenticatedUser, AccessAnnotationChecker accessChecker) {
        this.authenticatedUser = authenticatedUser;
        this.accessChecker = accessChecker;

        setPrimarySection(Section.DRAWER);
        addDrawerContent();
        addHeaderContent();
    }

    private void addHeaderContent() {
        DrawerToggle toggle = new DrawerToggle();
        toggle.setAriaLabel("Menu toggle");

        viewTitle = new H2();
        viewTitle.addClassNames(LumoUtility.FontSize.LARGE, LumoUtility.Margin.NONE);

        addToNavbar(true, toggle, viewTitle);
    }

    private void addDrawerContent() {
        H1 appName = new H1("Incidenti");
        appName.addClassNames(LumoUtility.FontSize.LARGE, LumoUtility.Margin.NONE);
        Header header = new Header(appName);

        Scroller scroller = new Scroller(createNavigation());

        addToDrawer(header, scroller, createFooter());
    }

    private SideNav createNavigation() {
        SideNav nav = new SideNav();

        if (accessChecker.hasAccess(DashboardView.class)) {
            nav.addItem(new SideNavItem("Dashboard", DashboardView.class,
                    LineAwesomeIcon.ANGLE_DOUBLE_RIGHT_SOLID.create()));

        }
        if (accessChecker.hasAccess(IncidentsView.class)) {
            nav.addItem(new SideNavItem("Incidents", IncidentsView.class,
                    LineAwesomeIcon.ARROW_ALT_CIRCLE_RIGHT_SOLID.create()));

        }
        if (accessChecker.hasAccess(TypesView.class)) {
            nav.addItem(new SideNavItem("Types", TypesView.class, LineAwesomeIcon.ARROW_CIRCLE_RIGHT_SOLID.create()));

        }
        if (accessChecker.hasAccess(OriginsView.class)) {
            nav.addItem(
                    new SideNavItem("Origins", OriginsView.class, LineAwesomeIcon.ARROW_CIRCLE_RIGHT_SOLID.create()));

        }
        if (accessChecker.hasAccess(AmbitsView.class)) {
            nav.addItem(new SideNavItem("Ambits", AmbitsView.class, LineAwesomeIcon.ARROW_CIRCLE_RIGHT_SOLID.create()));

        }
        if (accessChecker.hasAccess(UsersView.class)) {
            nav.addItem(new SideNavItem("Users", UsersView.class, LineAwesomeIcon.USERS_SOLID.create()));

        }
        if (accessChecker.hasAccess(SettingsView.class)) {
            nav.addItem(new SideNavItem("Settings", SettingsView.class, LineAwesomeIcon.USER_COG_SOLID.create()));

        }

        return nav;
    }

    private Footer createFooter() {
        Footer layout = new Footer();

        Optional<User> maybeUser = authenticatedUser.get();
        if (maybeUser.isPresent()) {
            User user = maybeUser.get();

            Avatar avatar = new Avatar(user.getFullName());
            avatar.setThemeName("xsmall");
            avatar.getElement().setAttribute("tabindex", "-1");

            MenuBar userMenu = new MenuBar();
            userMenu.setThemeName("tertiary-inline contrast");

            MenuItem userName = userMenu.addItem("");
            Div div = new Div();
            div.add(avatar);
            div.add(user.getFullName());
            div.add(new Icon("lumo", "dropdown"));
            div.getElement().getStyle().set("display", "flex");
            div.getElement().getStyle().set("align-items", "center");
            div.getElement().getStyle().set("gap", "var(--lumo-space-s)");
            userName.add(div);
            userName.getSubMenu().addItem("Sign out", e ->
                    authenticatedUser.logout()
            );

            layout.add(userMenu);
            layout.getStyle().set("background-color","#e8eded");
        } else {
            Anchor loginLink = new Anchor("login", "Sign in");
            layout.add(loginLink);
        }

        return layout;
    }

    @Override
    protected void afterNavigation() {
        super.afterNavigation();
        viewTitle.setText(getCurrentPageTitle());
    }

    private String getCurrentPageTitle() {
        PageTitle title = getContent().getClass().getAnnotation(PageTitle.class);
        return title == null ? "" : title.value();
    }
}
