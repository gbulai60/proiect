package com.cedacri.incidenti.repository;

import com.cedacri.incidenti.model.IncidentType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface IncidentTypeRepository extends JpaRepository<IncidentType,Integer>, JpaSpecificationExecutor<IncidentType> {
    IncidentType findIncidentTypeByName(String name);
}
