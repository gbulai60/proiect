package com.cedacri.incidenti.service.implementation;

import com.cedacri.incidenti.model.IncidentOrigin;
import com.cedacri.incidenti.repository.IncidentOriginRepository;
import com.cedacri.incidenti.service.IncidentOriginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class IncidentOriginServiceImpl implements IncidentOriginService {

    private final IncidentOriginRepository incidentOriginRepository;

    @Autowired
    public IncidentOriginServiceImpl(IncidentOriginRepository incidentOriginRepository) {
        this.incidentOriginRepository = incidentOriginRepository;
    }

    @Override
    @Transactional
    public IncidentOrigin save(IncidentOrigin incidentOrigin) {
        return incidentOriginRepository.save(incidentOrigin);
    }

    @Override
    public IncidentOrigin update(Integer id, IncidentOrigin incidentOrigin) {
        Optional<IncidentOrigin> existingOrigin = incidentOriginRepository.findById(id);
        if (existingOrigin.isPresent()) {
            IncidentOrigin origin = existingOrigin.get();
            origin.setName(incidentOrigin.getName());
            incidentOriginRepository.save(origin);
            return origin;
        } else {
            return null;
        }
    }

    @Override
    public Optional<IncidentOrigin> findById(Integer id) {
        return incidentOriginRepository.findById(id);
    }

    @Override
    public List<IncidentOrigin> findAll() {
        return incidentOriginRepository.findAll();
    }

    @Override
    public boolean delete(Integer id) {
        Optional<IncidentOrigin> optionalIncidentOrigin = incidentOriginRepository.findById(id);
        if (optionalIncidentOrigin.isPresent()) {
            incidentOriginRepository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public Page<IncidentOrigin> list(Pageable pageable) {
        return incidentOriginRepository.findAll(pageable);
    }

    @Override
    public Page<IncidentOrigin> list(Pageable pageable, Specification<IncidentOrigin> filter) {
        return incidentOriginRepository.findAll(filter, pageable);
    }
}
