package com.cedacri.incidenti.views.components.dialogs;

import com.cedacri.incidenti.model.Role;
import com.cedacri.incidenti.model.User;
import com.cedacri.incidenti.views.components.Buttons;
import com.cedacri.incidenti.views.components.userfields.ConfirmPassword;
import com.cedacri.incidenti.views.components.userfields.Password;
import com.vaadin.flow.component.ComponentUtil;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.combobox.MultiSelectComboBox;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.BeanValidationBinder;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDateTime;
import java.util.List;
import java.util.function.Consumer;

public class UserDialogs {

    private final PasswordEncoder passwordEncoder;

    private static final int ENABLED = 1;

    private final TextField fullName = new TextField("Full Name");

    private final TextField username = new TextField("Username");

    private final Password password = new Password("Password");

    private final TextField email = new TextField("Email");

    private final MultiSelectComboBox<Role> roles = new MultiSelectComboBox<>("Roles");

    private final ConfirmPassword confirmPassword = new ConfirmPassword("Confirm password");

    private final BeanValidationBinder<User> binder = new BeanValidationBinder<>(User.class);

    private final Dialog dialog = new Dialog();

    public UserDialogs(PasswordEncoder passwordEncoder, List<Role> rolesList) {
        this.passwordEncoder = passwordEncoder;
        dialog.setWidth("30%");
        binder.bindInstanceFields(this);
        roles.setItems(rolesList);
        roles.setItemLabelGenerator(Role::getName);
        binder.setValidatorsDisabled(true);
    }

    public void getUserDialog(Consumer<User> saveHandler, Runnable closeHandler) {
        if (ComponentUtil.getData(UI.getCurrent(), User.class)!= null) {
            dialog.setHeaderTitle("Update user");
            binder.setBean(ComponentUtil.getData(UI.getCurrent(), User.class));
            roles.setValue(binder.getBean().getRoles());
            disablePassword();
        } else {
            binder.setBean(new User());
            dialog.setHeaderTitle("Create user");
        }
        Button saveButton = Buttons.getSaveButton("Save", e -> {
            binder.setValidatorsDisabled(false);
            binder.validate();
            validatePassword();
            if (binder.isValid() && !password.isInvalid() && !confirmPassword.isInvalid()) {
                if (isNewUser(binder.getBean())) {
                    binder.getBean().setCreated(LocalDateTime.now());
                    binder.getBean().setHashedPassword(passwordEncoder.encode(password.getValue()));
                    binder.getBean().setIsEnabled(ENABLED);
                }
                saveHandler.accept(binder.getBean());
                closeAndClear();
            }

        });
        confirmPassword.addValueChangeListener(e -> {
            confirmPassword.setInvalid(!confirmPassword.getValue().equals(password.getValue()));
            if (!binder.isValidatorsDisabled()) {
                saveButton.setEnabled(isUserFormValid());
            }
        });
        binder.addStatusChangeListener(e -> {
            saveButton.setEnabled(isUserFormValid());
        });
        Button cancelButton = Buttons.getCancelButton("Discard", e -> {
            closeHandler.run();
            closeAndClear();
        });
        dialog.add(getUserFormLayout(saveButton,cancelButton));
        dialog.open();
    }

    private VerticalLayout getUserFormLayout(Button saveButton,Button cancelButton){
        VerticalLayout userFormLayout = new VerticalLayout(fullName, email, roles, username, password, confirmPassword, saveButton, cancelButton);
        userFormLayout.setAlignItems(FlexComponent.Alignment.STRETCH);
        return userFormLayout;
    }

    private void disablePassword() {
        password.setVisible(false);
        password.setInvalid(false);
        confirmPassword.setVisible(false);
        confirmPassword.setInvalid(false);
    }

    private boolean isUserFormValid() {
        return binder.isValid() && !confirmPassword.isInvalid() && !password.isInvalid();
    }

    private boolean isNewUser(User user) {
        return user.getId() == null;
    }

    private boolean isInvalidPassword() {
        return password.getValue().isEmpty() || password.getValue().isBlank();
    }

    private void validatePassword() {
        if (isInvalidPassword() && isNewUser(binder.getBean())) {
            password.setInvalid(true);
            confirmPassword.setInvalid(true);
        } else {
            password.setInvalid(false);
        }
    }

    private void closeAndClear() {
        dialog.close();
        binder.setBean(new User());
        roles.clear();
    }

}
