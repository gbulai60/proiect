package com.cedacri.incidenti.service;

import com.cedacri.incidenti.model.Incident;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import java.util.List;
import java.util.Optional;

public interface IncidentService {

    Incident save(Incident incident);

    Incident update(Incident incident);

    Optional<Incident> findById(Integer id);

    List<Incident> findAll();

    boolean delete(Integer id);

    Page<Incident> list(Pageable pageable);

    Page<Incident> list(Pageable pageable, Specification<Incident> filter);
}
