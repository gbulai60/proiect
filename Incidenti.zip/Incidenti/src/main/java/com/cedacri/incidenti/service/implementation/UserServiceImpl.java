package com.cedacri.incidenti.service.implementation;

import com.cedacri.incidenti.model.User;
import com.cedacri.incidenti.repository.UserRepository;
import com.cedacri.incidenti.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;

    @Autowired
    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    @Transactional
    public User save(User user) {
        int currentUserId = getUserFromSecurityContext().getId();
        user.setCreatedBy(currentUserId);
        user.setLastModifiedBy(currentUserId);
        return userRepository.save(user);
    }

    @Override
    @Transactional

    public User update(User user) {
        Optional<User> existingUser = userRepository.findById(user.getId());
        if (existingUser.isPresent()) {
            int currentUserId = getUserFromSecurityContext().getId();
            user.setLastModifiedBy(currentUserId);
            return userRepository.save(user);
        }
        return null;
    }

    @Override
    @Transactional
    public User findById(Integer id) {
        Optional<User> existingUser = userRepository.findById(id);
        return existingUser.orElse(null);
    }

    @Override
    public List<User> findAll() {
        return userRepository.findAll();
    }

    @Override
    @Transactional
    public boolean delete(Integer id) {
        Optional<User> optionalUser = userRepository.findById(id);
        if (optionalUser.isPresent()) {
            userRepository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public User getUserByUserName(String username) {
        return userRepository.findUserByUsername(username);
    }

    @Override
    public User getUserFromSecurityContext() {
        return userRepository.findUserByUsername(
                SecurityContextHolder
                        .getContext()
                        .getAuthentication()
                        .getName());
    }

    @Override
    public Page<User> list(Pageable pageable) {
        return userRepository.findAll(pageable);
    }

    @Override
    public Page<User> list(Pageable pageable, Specification<User> filter) {
        return userRepository.findAll(filter, pageable);
    }
}
