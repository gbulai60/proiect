package com.cedacri.incidenti.views.components.filters;

import com.cedacri.incidenti.model.IncidentOrigin;
import com.cedacri.incidenti.service.IncidentOriginService;
import com.cedacri.incidenti.views.components.Buttons;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.textfield.IntegerField;
import com.vaadin.flow.theme.lumo.LumoUtility;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import lombok.NonNull;
import org.springframework.data.jpa.domain.Specification;

import java.util.ArrayList;
import java.util.List;

public class OriginFilters extends Div implements Specification<IncidentOrigin> {
    private final IntegerField idFilter = new IntegerField("Id");
    private final ComboBox<String> nameFilter = new ComboBox<>("Origin");
    private final Runnable onSearch;

    public OriginFilters(Runnable onSearch, IncidentOriginService originService) {
        this.onSearch = onSearch;

        setWidthFull();
        addClassName("filter-layout");
        addClassNames(LumoUtility.Padding.Horizontal.LARGE, LumoUtility.Padding.Vertical.MEDIUM,
                LumoUtility.BoxSizing.BORDER);

        idFilter.setPlaceholder("Id");
        nameFilter.setPlaceholder("Name");

        nameFilter.setItems(originService.findAll().stream().map(IncidentOrigin::getName).toList());

        Button resetBtn = Buttons.getResetFiltersButton("Reset", e -> resetFilters());
        Button searchBtn = Buttons.getSearchBtn(onSearch);

        Div actions = new Div(resetBtn, searchBtn);
        actions.addClassName(LumoUtility.Gap.SMALL);
        actions.addClassName("actions");

        add(idFilter, nameFilter, actions);
    }
    
    private void resetFilters(){
        idFilter.clear();
        nameFilter.clear();
        onSearch.run();
    }

    @Override
    public Predicate toPredicate(@NonNull Root<IncidentOrigin> root, @NonNull CriteriaQuery<?> query, @NonNull CriteriaBuilder criteriaBuilder) {
        List<Predicate> predicates = new ArrayList<>();
        if (!idFilter.isEmpty()) {
            Integer typeIdFilter = idFilter.getValue();
            Predicate fullName = criteriaBuilder.equal(root.get("id"),
                    typeIdFilter);
            predicates.add(criteriaBuilder.or(fullName));
        }
        if (!nameFilter.isEmpty()) {
            Predicate fullName = criteriaBuilder.like(criteriaBuilder.lower(root.get("name")),
                    nameFilter.getValue().toLowerCase() + "%");
            predicates.add(criteriaBuilder.or(fullName));
        }

        return criteriaBuilder.and(predicates.toArray(Predicate[]::new));
    }
}