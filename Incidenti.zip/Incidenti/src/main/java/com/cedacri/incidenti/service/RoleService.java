package com.cedacri.incidenti.service;

import com.cedacri.incidenti.model.Role;

import java.util.List;

public interface RoleService {

    List<Role> findAll();
}
