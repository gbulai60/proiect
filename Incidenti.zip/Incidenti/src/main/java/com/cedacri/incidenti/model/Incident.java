package com.cedacri.incidenti.model;

import com.cedacri.incidenti.utils.ConstraintMessages;
import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "incidents")
public class Incident {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "created_by")
    @Min(1)
    private Integer createdBy;

    @Column(name = "created")
    private LocalDateTime created;

    @Column(name = "last_modified_by")
    @NotNull(message = ConstraintMessages.INCIDENT_LAST_MODIFIED_BY_NOT_BLANK)
    @Min(1)
    private Integer lastModifiedBy;

    @Column(name = "last_modified")
    @NotNull(message = ConstraintMessages.INCIDENT_LAST_MODIFIED_DATE_NOT_BLANK)
    private LocalDateTime lastModified;

    @Column(name = "request_nr")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "req_gen")
    @SequenceGenerator(name="req_gen", sequenceName ="req_gen_seq", allocationSize = 1)
    private Integer requestNumber;

    @Column(name = "subsystem")
    @NotBlank(message = ConstraintMessages.INCIDENT_SUBSYSTEM_NOT_BLANK)
    private String subsystem;

    @Column(name = "open_date")
    private LocalDateTime openDate;

    @Column(name = "close_date")
    private LocalDateTime closeDate;

    @ManyToOne
    @JoinColumn(name = "incident_type_id")
    @NotNull(message = ConstraintMessages.INCIDENT_TYPE_ID_NOT_BLANK)
    private IncidentType incidentType;

    @Column(name = "application_type")
    @NotBlank(message = ConstraintMessages.INCIDENT_APPLICATION_TYPE_NOT_BLANK)
    private String applicationType;

    @Column(name = "urgency")
    @NotBlank(message = ConstraintMessages.INCIDENT_URGENCY_NOT_BLANK)
    private String urgency;

    @Column(name = "subcause")
    @NotBlank(message = ConstraintMessages.INCIDENT_SUBCAUSE_NOT_BLANK)
    private String subcause;

    @Column(name = "problem_summary")
    @NotBlank(message = ConstraintMessages.INCIDENT_PROBLEM_SUMMARY_NOT_BLANK)
    private String problemSummary;

    @Column(name = "problem_description")
    @NotBlank(message = ConstraintMessages.INCIDENT_PROBLEM_DESCRIPTION_NOT_BLANK)
    private String problemDescription;

    @ManyToOne
    @JoinColumn(name = "origin_id")
    @NotNull(message = ConstraintMessages.INCIDENT_ORIGIN_ID_NOT_BLANK)
    private IncidentOrigin origin;
}