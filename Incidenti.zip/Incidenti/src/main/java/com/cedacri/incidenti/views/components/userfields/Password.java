package com.cedacri.incidenti.views.components.userfields;

import com.vaadin.flow.component.textfield.PasswordField;

public class Password extends PasswordField {

    private static final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?!.*\\s).{8,}$";

    private static final String ERROR_MESSAGE = "Password must contain at least one digit, one uppercase letter, one special symbol, and be at least 8 characters long";

    public Password(String label){
        super(label);
        super.setMinLength(8);
        super.setPattern(PASSWORD_PATTERN);
        super.setErrorMessage(ERROR_MESSAGE);
        super.setRequiredIndicatorVisible(true);
    }
}
