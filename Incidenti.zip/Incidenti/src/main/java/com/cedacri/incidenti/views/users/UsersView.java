package com.cedacri.incidenti.views.users;

import com.cedacri.incidenti.model.Role;
import com.cedacri.incidenti.model.User;
import com.cedacri.incidenti.service.RoleService;
import com.cedacri.incidenti.service.UserService;
import com.cedacri.incidenti.views.MainLayout;
import com.cedacri.incidenti.views.components.Buttons;
import com.cedacri.incidenti.views.components.Layouts;
import com.cedacri.incidenti.views.components.Notifications;
import com.cedacri.incidenti.views.components.dialogs.Dialogs;
import com.cedacri.incidenti.views.components.dialogs.UserDialogs;
import com.cedacri.incidenti.views.components.filters.UserFilters;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentUtil;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.confirmdialog.ConfirmDialog;
import com.vaadin.flow.component.dependency.Uses;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.data.renderer.ComponentRenderer;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.spring.data.VaadinSpringDataHelpers;
import com.vaadin.flow.theme.lumo.LumoUtility;
import jakarta.annotation.security.RolesAllowed;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;

@PageTitle("Users")
@Route(value = "users", layout = MainLayout.class)
@RolesAllowed("ADMIN")
@Uses(Icon.class)
public class UsersView extends Div {

    private Grid<User> grid;

    private final UserFilters filters;

    private final UserService userService;

    public final RoleService roleService;

    private final Button createUserButton;

    private final PasswordEncoder passwordEncoder;

    @Autowired
    public UsersView(UserService userService, RoleService roleService, PasswordEncoder passwordEncoder) {
        this.userService = userService;
        this.roleService = roleService;
        this.passwordEncoder = passwordEncoder;
        setSizeFull();
        addClassNames("users-view");

        filters = new UserFilters(this::refreshGrid, this.roleService);
        createUserButton = new Button("Create user", e -> openCreateDialog());
        VerticalLayout layout = new VerticalLayout(Layouts.getMobileFilters(filters), filters, createButtonsLayout(), createGrid());
        layout.setSizeFull();
        layout.setPadding(false);
        layout.setSpacing(false);

        add(layout);
    }

    private HorizontalLayout createButtonsLayout(){
        return Layouts.getButtonsLayout(createUserButton);
    }

    private HorizontalLayout createComponentButtonsLayout(User item){
        Button editButton = Buttons.getEditButton(e -> openEditDialog(item));
        Button deleteButton = Buttons.getDeleteButton(e -> openDeleteDialog(item.getId()));

        return Layouts.getActionsLayout(editButton, deleteButton);
    }

    private Component createGrid(){
        Grid<User> grid = createUsersGrid();
        grid.addThemeVariants(GridVariant.LUMO_NO_BORDER);
        grid.addClassNames(LumoUtility.Border.TOP, LumoUtility.BorderColor.CONTRAST_10);

        return grid;
    }

    private Grid<User> createUsersGrid() {
        grid = new Grid<>(User.class, false);
        grid.addColumn("isEnabled").setAutoWidth(true).setHeader("Enabled")
                .setRenderer(new ComponentRenderer<>(isEnabled -> {
                    Icon icon;
                    if (isEnabled.getIsEnabled() == 1) {
                        icon = new Icon(VaadinIcon.CHECK);
                        icon.getElement().getThemeList().add("badge success");
                    } else {
                        icon = new Icon(VaadinIcon.CLOSE);
                        icon.getElement().getThemeList().add("badge error");
                    }
                    return icon;
                }));
        grid.addColumn("id").setAutoWidth(true);
        grid.addColumn("fullName").setAutoWidth(true);
        grid.addColumn("email").setAutoWidth(true);
        grid.addColumn("username").setAutoWidth(true);
        grid.addColumn("created").setAutoWidth(true).setHeader("Created date");
        grid.addColumn("createdBy").setAutoWidth(true).setHeader("Creator id");
        grid.addColumn("lastModifiedBy").setAutoWidth(true).setHeader("Modifier id");
        grid.addComponentColumn(this::createComponentButtonsLayout).setHeader("Actions");
        grid.setItems(query -> userService.list(
                PageRequest.of(query.getPage(), query.getPageSize(), VaadinSpringDataHelpers.toSpringDataSort(query)),
                filters).stream());

        return grid;
    }

    private void refreshGrid() {
        grid.getDataProvider().refreshAll();
    }

    private void openEditDialog(User item){
        List<Role> roles = roleService.findAll();
        UserDialogs userDialogs = new UserDialogs(passwordEncoder,roles);
        ComponentUtil.setData(UI.getCurrent(),User.class, item);
        userDialogs.getUserDialog( this::saveUser, this::refreshGrid);
        ComponentUtil.setData(UI.getCurrent(),User.class, null);
    }

    private void openCreateDialog(){
        List<Role> roles = roleService.findAll();
        UserDialogs userDialogs = new UserDialogs(passwordEncoder,roles);

        userDialogs.getUserDialog(this::saveUser, this::refreshGrid);

    }

    private void openDeleteDialog(Integer id){
        ConfirmDialog deleteDialog = Dialogs.getDeleteDialog(id, this::deleteUser);
        deleteDialog.open();
    }

    private void saveUser(User user){
        userService.save(user);
        Notifications.showSuccessNotification("User save successfully!");
        refreshGrid();
    }

    private void deleteUser(Integer id){
        userService.delete(id);
        Notifications.showSuccessNotification("User deleted successfully");
        refreshGrid();
    }
}
