package com.cedacri.incidenti.views.settings;

import com.cedacri.incidenti.model.User;
import com.cedacri.incidenti.security.AuthenticatedUser;
import com.cedacri.incidenti.service.UserService;
import com.cedacri.incidenti.views.MainLayout;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.confirmdialog.ConfirmDialog;
import com.vaadin.flow.component.dependency.Uses;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.H3;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.notification.NotificationVariant;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.textfield.PasswordField;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import jakarta.annotation.security.PermitAll;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

@PageTitle("Settings")
@Route(value = "settings", layout = MainLayout.class)
@PermitAll
@Uses(Icon.class)
public class SettingsView extends Div {
    private final TextField username = new TextField("Username");
    private final PasswordField password = new PasswordField("Password");
    private final PasswordField confirmPassword = new PasswordField("Confirm password");
    private final Button cancel = new Button("Cancel");
    private final Button save = new Button("Save");
    private final PasswordEncoder passwordEncoder;

    public SettingsView(UserService userService, AuthenticatedUser authenticatedUser, PasswordEncoder passwordEncoder) {
        this.passwordEncoder = passwordEncoder;
        Optional<User> maybeUser = authenticatedUser.get();
        addClassName("settings-view");

        add(createTitle());
        add(createFormLayout());
        add(createButtonLayout());
        if (maybeUser.isPresent()) {
            User user = maybeUser.get();
            username.setValue(user.getUsername());

            cancel.addClickListener(e -> clearForm());
            save.addClickListener(e -> {
                ConfirmDialog dialog = new ConfirmDialog();
                dialog.setHeader("Unsaved changes");
                dialog.setText(
                        "There are unsaved changes. Do you want to discard or save them?");

                dialog.setCancelable(true);
                dialog.addCancelListener(event -> Notification.show("Canceled details update."));

                dialog.setRejectable(true);
                dialog.setRejectText("Discard");
                dialog.addRejectListener(event ->
                        Notification.show("Discard details update."));

                dialog.setConfirmText("Save");
                dialog.addConfirmListener(event -> {
                    boolean isValid = true;
                    if (username.getValue().isBlank() && username.getValue().isEmpty()) {
                        isValid = false;
                        Notification notification = new Notification("Username cannot be empty!", 3000);
                        notification.addThemeVariants(NotificationVariant.LUMO_ERROR);
                        notification.open();
                    }
                    if (userService.getUserByUserName(username.getValue()) != null &&
                            !userService.getUserFromSecurityContext().getUsername().equals(username.getValue())){
                        isValid = false;
                        Notification notification = new Notification("User with username '"+username.getValue()+"' already exist!", 3000);
                        notification.addThemeVariants(NotificationVariant.LUMO_ERROR);
                        notification.open();
                    }
                    if (password.getValue().isBlank() && password.getValue().isEmpty()) {
                        isValid = false;
                        Notification notification = new Notification("Invalid password!", 3000);
                        notification.addThemeVariants(NotificationVariant.LUMO_ERROR);
                        notification.open();
                    }
                    if (isValid){
                        user.setUsername(username.getValue());
                        user.setHashedPassword(this.passwordEncoder.encode(password.getValue()));
                        userService.update(user);
                        Notification.show(user.getFullName() + " details update.");
                    }
                });

                if (password.getValue().equals(confirmPassword.getValue())) {
                    dialog.open();
                } else
                    clearForm();
            });
        }

    }

    private void clearForm() {
        username.clear();
        password.clear();
        confirmPassword.clear();
    }

    private Component createTitle() {
        return new H3("Personal information");
    }

    private Component createFormLayout() {
        FormLayout formLayout = new FormLayout();
        formLayout.add(username, password, confirmPassword);
        return formLayout;
    }

    private Component createButtonLayout() {
        HorizontalLayout buttonLayout = new HorizontalLayout();
        buttonLayout.addClassName("button-layout");
        save.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
        buttonLayout.add(save);
        buttonLayout.add(cancel);
        return buttonLayout;
    }
}
