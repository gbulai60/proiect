package com.cedacri.incidenti.views.components.dialogs;

import com.cedacri.incidenti.model.IncidentOrigin;
import com.cedacri.incidenti.utils.ConstraintMessages;
import com.cedacri.incidenti.views.components.Buttons;
import com.cedacri.incidenti.views.components.Notifications;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.Binder;
import jakarta.validation.constraints.NotNull;

import java.util.function.Consumer;

public class OriginDialogs {

    public static Dialog editOriginDialog(IncidentOrigin item, Consumer<IncidentOrigin> saveHandler, Runnable closeHandler){
        Dialog dialog = new Dialog();
        dialog.setHeaderTitle("Edit origin");
        dialog.setWidth("30%");

        TextField originNameField = new TextField("Name", item.getName());

        return getDialog(item, saveHandler, closeHandler, dialog, originNameField);
    }

    public static Dialog createOriginDialog(Consumer<IncidentOrigin> saveHandler, Runnable closeHandler){
        Dialog dialog = new Dialog();
        dialog.setHeaderTitle("New Origin");

        TextField originNameField = new TextField("Name");

        IncidentOrigin origin = new IncidentOrigin();

        return getDialog(origin, saveHandler, closeHandler, dialog, originNameField);
    }

    @NotNull
    private static Dialog getDialog(IncidentOrigin item, Consumer<IncidentOrigin> saveHandler, Runnable closeHandler, Dialog dialog, TextField originNameField) {

        Binder<IncidentOrigin> binder = new Binder<>(IncidentOrigin.class);
        binder.setBean(item);
        binder.setValidatorsDisabled(true);

        binder.forField(originNameField)
                .asRequired("Origin name cannot be blank")
                .bind(IncidentOrigin::getName, IncidentOrigin::setName);

        Button saveButton = Buttons.getSaveButton("Save", e -> {
            binder.setValidatorsDisabled(false);
            binder.validate();
            if(binder.writeBeanIfValid(item)){
                saveHandler.accept(item);
                dialog.close();
            }
            else{
                Notifications.showErrorNotification(ConstraintMessages.FILL_OUT_FIELDS_MESSAGE);
            }
        });

        Button cancelButton = Buttons.getCancelButton("Cancel", e -> {
            closeHandler.run();
            dialog.close();
        });

        VerticalLayout fieldsLayout = new VerticalLayout(originNameField, saveButton, cancelButton);
        fieldsLayout.setAlignItems(FlexComponent.Alignment.STRETCH);
        dialog.add(fieldsLayout);

        return dialog;
    }
}
