package com.cedacri.incidenti.utils.converter;

import com.cedacri.incidenti.model.IncidentType;
import com.cedacri.incidenti.service.IncidentTypeService;
import com.vaadin.flow.data.binder.Result;
import com.vaadin.flow.data.binder.ValueContext;
import com.vaadin.flow.data.converter.Converter;

import java.util.List;

public class StringToIncidentTypeConverter implements Converter<String, IncidentType> {

    private List<IncidentType> incidentTypes;

    public StringToIncidentTypeConverter(List<IncidentType> incidentTypes){
        this.incidentTypes = incidentTypes;
    }
    @Override
    public Result<IncidentType> convertToModel(String value, ValueContext context) {

        if(value == null){
            return Result.ok(null);
        }

        for(IncidentType type : incidentTypes){
            if(type.getName().equals(value)){
                return Result.ok(type);
            }
        }

        return Result.error("Unknown incident type: " + value);
    }

    @Override
    public String convertToPresentation(IncidentType value, ValueContext context) {
        return value != null ? value.getName() : "";
    }
}
