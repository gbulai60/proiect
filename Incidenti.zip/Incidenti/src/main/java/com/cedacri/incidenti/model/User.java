package com.cedacri.incidenti.model;

import com.cedacri.incidenti.utils.ConstraintMessages;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.Set;

@Entity
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "users")
public class User{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "created_by")
    @NotNull(message = ConstraintMessages.USER_CREATED_BY_NOT_NULL)
    private Integer createdBy;

    @Column(name = "created")
    @NotNull(message = ConstraintMessages.USER_CREATED_NOT_NULL)
    private LocalDateTime created;

    @Column(name = "last_modified_by")
    @NotNull(message = ConstraintMessages.USER_LAST_MODIFIED_BY_NOT_NULL)
    private Integer lastModifiedBy;

    @Column(name = "username")
    @NotBlank(message = ConstraintMessages.USER_USERNAME_NOT_BLANK)
    @NotEmpty(message = ConstraintMessages.USER_USERNAME_IS_REQUIRED)
    private String username;

    @Column(name = "password")
    @NotBlank(message = ConstraintMessages.USER_PASSWORD_NOT_BLANK)
    @JsonIgnore
    private String hashedPassword;

    @Column(name = "full_name")
    @NotBlank(message = ConstraintMessages.USER_FULL_NAME_NOT_BLANK)
    @Pattern(regexp = "^[A-Z][a-z]+(?:\\s+[A-Z][a-z]+)+$",message = ConstraintMessages.USER_FULL_NAME_PATTERN)
    private String fullName;

    @Column(name = "email")
    @Pattern(regexp = "^[\\w-.]+@([\\w-]+\\.)+[\\w-]{2,4}$", message = ConstraintMessages.USER_EMAIL_NOT_VALID)
    private String email;

    @Column(name = "is_enabled")
    @NotNull(message = ConstraintMessages.USER_IS_ENABLED_NOT_NULL)
    @Min(value = 0, message = ConstraintMessages.USER_IS_ENABLED_VALUE)
    @Max(value = 1, message = ConstraintMessages.USER_IS_ENABLED_VALUE)
    private Integer isEnabled;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "user_roles",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "role_id"),
            uniqueConstraints = @UniqueConstraint(columnNames = {"user_id", "role_id"})
    )
    @NotEmpty(message = ConstraintMessages.ROLE_IS_REQUIRED)
    private Set<Role> roles;
    public User(LocalDateTime created,String username, String hashedPassword, String fullName, String email, Integer isEnabled, Set<Role> roles) {
        this.created = created;
        this.username = username;
        this.hashedPassword = hashedPassword;
        this.fullName = fullName;
        this.email = email;
        this.isEnabled = isEnabled;
        this.roles = roles;
    }
    @Override
    public int hashCode() {
        if (getId() != null) {
            return getId().hashCode();
        }
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof User that)) {
            return false;
        }
        if (getId() != null) {
            return getId().equals(that.getId());
        }
        return super.equals(that);
    }
}