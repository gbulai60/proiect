package com.cedacri.incidenti.views.components.dialogs;

import com.cedacri.incidenti.model.IncidentAmbit;
import com.cedacri.incidenti.model.IncidentType;
import com.cedacri.incidenti.utils.ConstraintMessages;
import com.cedacri.incidenti.utils.converter.StringToIncidentAmbitConverter;
import com.cedacri.incidenti.views.components.Buttons;
import com.cedacri.incidenti.views.components.Notifications;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.Binder;
import jakarta.validation.constraints.NotNull;

import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;

public class TypeDialogs {

    public static Dialog editTypeDialog(IncidentType item, List<IncidentAmbit> ambits, Consumer<IncidentType> saveHandler, Runnable closeHandler){
        Dialog dialog = new Dialog();
        dialog.setHeaderTitle("Edit type");
        dialog.setWidth("30%");

        TextField typeNameField = new TextField("Name", item.getName());
        typeNameField.setValue(item.getName());

        ComboBox<String> ambitsCombo = new ComboBox<>();
        ambitsCombo.setItems(ambits.stream().map(IncidentAmbit::getName).toList());
        ambitsCombo.setValue(item.getAmbit().getName());

        return getDialog(item, ambits, saveHandler, closeHandler, dialog, typeNameField, ambitsCombo);
    }

    public static Dialog createTypeDialog(List<IncidentAmbit> ambits, Consumer<IncidentType> saveHandler, Runnable closeHandler){
        Dialog dialog = new Dialog();
        dialog.setHeaderTitle("New type");
        dialog.setWidth("30%");

        IncidentType type = new IncidentType();

        TextField typeNameField = new TextField("Name");
        ComboBox<String> ambitCombo = new ComboBox<>("Ambit");
        ambitCombo.setItems(ambits.stream()
                .map(IncidentAmbit::getName).toList());

        return getDialog(type, ambits, saveHandler, closeHandler, dialog, typeNameField, ambitCombo);
    }

    @NotNull
    private static Dialog getDialog(IncidentType item, List<IncidentAmbit> ambits, Consumer<IncidentType> saveHandler, Runnable closeHandler, Dialog dialog, TextField typeNameField, ComboBox<String> ambitsCombo) {

        Binder<IncidentType> binder = new Binder<>(IncidentType.class);
        binder.setBean(item);
        binder.setValidatorsDisabled(true);

        binder.forField(typeNameField)
                .asRequired("Type name cannot be blank")
                .bind(IncidentType::getName, IncidentType::setName);

        binder.forField(ambitsCombo)
                .withConverter(new StringToIncidentAmbitConverter(ambits))
                .withValidator(Objects::nonNull, "Ambit cannot be blank")
                .bind(IncidentType::getAmbit, IncidentType::setAmbit);


        Button saveButton = Buttons.getSaveButton("Save", e -> {
            binder.setValidatorsDisabled(false);
            binder.validate();

            if(binder.writeBeanIfValid(item)){
                saveHandler.accept(item);
                dialog.close();
            }
            else {
                Notifications.showErrorNotification(ConstraintMessages.FILL_OUT_FIELDS_MESSAGE);
            }
        });

        Button cancelButton = Buttons.getCancelButton("Cancel", e -> {
            closeHandler.run();
            dialog.close();
        });

        VerticalLayout fieldsLayout = new VerticalLayout(typeNameField, ambitsCombo, saveButton, cancelButton);
        fieldsLayout.setAlignItems(FlexComponent.Alignment.STRETCH);
        dialog.add(fieldsLayout);

        return dialog;
    }
}
