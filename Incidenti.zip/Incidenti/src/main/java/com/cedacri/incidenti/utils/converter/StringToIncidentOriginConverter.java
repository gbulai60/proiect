package com.cedacri.incidenti.utils.converter;

import com.cedacri.incidenti.model.IncidentOrigin;
import com.cedacri.incidenti.model.IncidentType;
import com.vaadin.flow.data.binder.Result;
import com.vaadin.flow.data.binder.ValueContext;
import com.vaadin.flow.data.converter.Converter;

import java.util.List;

public class StringToIncidentOriginConverter implements Converter<String, IncidentOrigin> {
    private List<IncidentOrigin> incidentOrigins;

    public StringToIncidentOriginConverter(List<IncidentOrigin> incidentOrigins) {
        this.incidentOrigins = incidentOrigins;
    }

    @Override
    public Result<IncidentOrigin> convertToModel(String value, ValueContext context) {
        if(value == null){
            return Result.ok(null);
        }

        for(IncidentOrigin origin : incidentOrigins){
            if(origin.getName().equals(value)){
                return Result.ok(origin);
            }
        }

        return Result.error("Unknown incident origin: " + value);
    }

    @Override
    public String convertToPresentation(IncidentOrigin value, ValueContext context) {
        return value != null ? value.getName() : "";
    }
}
