    package com.cedacri.incidenti.model;

    import com.cedacri.incidenti.utils.ConstraintMessages;
    import jakarta.persistence.*;
    import jakarta.validation.constraints.NotBlank;
    import lombok.*;

    @Entity
    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @Table(name = "incident_ambits")
    public class IncidentAmbit {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Integer id;

        @Column(name = "name")
        @NotBlank(message = ConstraintMessages.INCIDENT_AMBIT_NAME_NOT_BLANK)
        private String name;
    }
