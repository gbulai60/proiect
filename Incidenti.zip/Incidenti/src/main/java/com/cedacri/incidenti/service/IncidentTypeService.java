package com.cedacri.incidenti.service;

import com.cedacri.incidenti.model.IncidentType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import java.util.List;
import java.util.Optional;

public interface IncidentTypeService {

    IncidentType save(IncidentType incidentType);

    IncidentType update(Integer id, IncidentType incidentType);

    Optional<IncidentType> findById(Integer id);

    List<IncidentType> findAll();

    boolean delete(Integer id);

    Page<IncidentType> list(Pageable pageable);

    Page<IncidentType>list(Pageable pageable, Specification<IncidentType> filter);
}
