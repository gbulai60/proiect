import {applyTheme as _applyTheme} from './theme-incidenti.generated.js';
export const applyTheme = _applyTheme;
